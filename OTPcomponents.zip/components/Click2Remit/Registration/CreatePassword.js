import { Form, Input, notification } from "antd";
import { useState } from "react";
import { AuthAPI } from "../../../apis/AuthAPI";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { ViAmericaAuthAPI } from "../../../apis/ViAmericaApi/Auth";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import useHttp from "../../../hooks/useHttp";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import Spinner from "../../../reusable/Spinner";
import { checkPassword } from "../../../services/validations/password";
export default function CreatePassword(props) {
  const { form } = props;
  // const [password, setPassword] = useState("");
  // const [charNumberValid,setCharNumberValid]= useState(false)
  // const [specialCharValid,setSpecialCharValid]= useState(false)
  // const [uppercaseValid,setUppercaseValid] = useState(false)
  // const [lowercaseValid,setLowercaseValid] = useState(false)
  // const [numberValid,setNumberValid] = useState(false)
  const [loader, setLoader] = useState(false);

  const hookSaveLeads = useHttp(AuthAPI.saveLeads);
  const hookSignUp = useHttp(AuthAPI.signUp);
  const hookSignUpViAmerica = useHttp(ViAmericaAuthAPI.signUp);
  const hookVerifyEmail = useHttp(ProfileAPI.emailVerification);

  const checkPasswordLength = (password) => {
    if (password.length >= 10) {
      props.setCharNumberValid(true);
    } else {
      props.setCharNumberValid(false);
    }
  };

  const checkSpecialCharacters = (password) => {
    const pattern = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/g;
    if (pattern.test(password)) {
      props.setSpecialCharValid(true);
    } else {
      props.setSpecialCharValid(false);
    }
  };

  const checkUppercase = (password) => {
    const pattern = /[A-Z]/;
    if (pattern.test(password)) {
      props.setUppercaseValid(true);
    } else {
      props.setUppercaseValid(false);
    }
  };
  const checkLowercase = (password) => {
    const pattern = /[a-z]/;
    if (pattern.test(password)) {
      props.setLowercaseValid(true);
    } else {
      props.setLowercaseValid(false);
    }
  };
  const checkNumber = (password) => {
    const pattern = /[0-9]/;
    if (pattern.test(password)) {
      props.setNumberValid(true);
    } else {
      props.setNumberValid(false);
    }
  };
  const handlePasswordChange = (event) => {
    props.setPassword(event.target.value);
    checkPasswordLength(event.target.value);
    checkSpecialCharacters(event.target.value);
    checkUppercase(event.target.value);
    checkLowercase(event.target.value);
    checkNumber(event.target.value);
  };

  const onCreateLead = (value) => {
    props.setState({ userPassword: value.passwords });
    const leadData = {
      loginId: props.state.personalDetails.email,
      utm_medium: "",
      bankCustID: props.state.personalDetails.crn,
      sameBankCust: "Y",
      emailId: props.state.personalDetails.email,
      sendCountry: props.state.residentialDetails.country,
      lpId: "",
      password: value.passwords,
      state: props.state.residentialDetails.state,
      twofa: "N",
      leadId: props.state.leadId,
      zip: props.state.residentialDetails.zipcode,
      marketingRef: "Google~",
      altMobileNo: "",
      marketingCommunication: "Y",
      tnc: "Y",
      firstName: props.state.personalDetails.firstName.trim(),
      recvCountry: "IN",
      nationality: "",
      dob: props.state.dob,
      pageReferer: "",
      custType: "INDIVIDUAL",
      passwordType: "PASSWORD",
      periodicUpdate: "Y",
      utm_source: "",
      lastName: props.state.personalDetails.lastName.trim(),
      gender: props.state.personalDetails.gender,
      city: props.state.residentialDetails.city,
      utm_campaig: "",
      verifiedToken: "",
      isEmailVerified: "Y",
      altMobilePhoneCode: "",
      accountNo: "",
      euroCountry: "",
      mobilePhoneCode: props.state.personalDetails.mobileCountryCode,
      utm_content: "",
      requestType: "LEAD",
      address2: props.state.residentialDetails.address2.trim(),
      address1: props.state.residentialDetails.address1.trim(),
      utm_adgroup: "",
      mobileNo: props.state.personalDetails.mobileNo,
      utm_term: "",
      middleName: props.state.personalDetails.middleName
        ? props.state.personalDetails.middleName.trim()
        : "",
      isMobileVerified: "N",
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      otpFlag: "N",
    };

    setLoader(true);
    hookSaveLeads.sendRequest(leadData, function (data) {
      setLoader(false);
      if (data.status == "S") {
        // notification.success({
        //   message: "OTP sent to your registered mobile number",
        // });
        // props.setState({
        //   activeStepForm: 4,
        //   verificationToken: data.verificationToken,
        //   leadId: data.leadId,
        // });
        notification.success({ message: data.message });
        props.setState({ leadId: data.leadId });
        signupAccount(data.leadId, value.passwords);
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
          // setLoader((prevState) => prevState - 1);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const signupAccount = (leadId, passwords) => {
    const signUPData = {
      loginId: props.state.personalDetails.email,
      utm_medium: "",
      bankCustID: props.state.personalDetails.crn,
      sameBankCust: "Y",
      emailId: props.state.personalDetails.email,
      sendCountry: props.state.residentialDetails.country,
      lpId: "",
      password: passwords,
      state: props.state.residentialDetails.state,
      twofa: "N",
      leadId: leadId,
      zip: props.state.residentialDetails.zipcode,
      marketingRef: "Google~",
      altMobileNo: "",
      marketingCommunication: "Y",
      tnc: "Y",
      firstName: props.state.personalDetails.firstName,
      recvCountry: "IN",
      nationality: "",
      dob: props.state.dob,
      pageReferer: "",
      custType: "INDIVIDUAL",
      passwordType: "PASSWORD",
      periodicUpdate: "Y",
      utm_source: "",
      lastName: props.state.personalDetails.lastName,
      gender: props.state.personalDetails.gender,
      city: props.state.residentialDetails.city,
      utm_campaig: "",
      verifiedToken: "",
      isEmailVerified: "Y",
      altMobilePhoneCode: "",
      accountNo: "",
      euroCountry: "",
      mobilePhoneCode: props.state.personalDetails.mobileCountryCode,
      utm_content: "",
      requestType: "SIGNUP",
      address2: props.state.residentialDetails.address2,
      address1: props.state.residentialDetails.address1,
      // address3: props.state.residentialDetails.address3,
      utm_adgroup: "",
      mobileNo: props.state.personalDetails.mobileNo,
      utm_term: "",
      middleName: props.state.personalDetails.middleName
        ? props.state.personalDetails.middleName.trim()
        : "",
      isMobileVerified: "N",
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      emailVeriFlag: true,
      
    };
    setLoader(true);
    hookSignUp.sendRequest(signUPData, function (data) {
      setLoader(false);
      if (data.status == "S") {
        notification.success({ message: data.message });
        // props.setState({ activeStepForm: 6 });
        if (props.state.residentialDetails.country == "US") {
          signUpViAmerica(data);
        } else {
          props.setState({ activeStepForm: 6 });
        }
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          if (error.field == "password") {
            notification.error({ message: error.error });
            form.setFields([{ name: "signup_password", errors: [error.error] }]);
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const signUpViAmerica = (data) => {
    setLoader(true);
    hookSignUpViAmerica.sendRequest(
      {
        requestType: "SIGNUP",
        userId: data.userId,
      },
      function (dataVia) {
        setLoader(false);
        if (dataVia.status === "S") {
          notification.success({
            message: "Thank you. You are successfully registered.",
          });
          // props.setState({ activeStepForm: 6 });
          emailVerify(data, dataVia);
        } else {
          notification.error({ message: dataVia.errorMessage });
        }
      },
    );
  };
  const emailVerify = (data, dataVia) => {
    let payload = {
      requestType: "VERIFICATIONEMAIL",
      loginId: props.state.personalDetails.email,
      userId: data.userId,
      emailId: props.state.personalDetails.email,
      emailVeriFlag: true,
    };
    setLoader(true);
    hookVerifyEmail.sendRequest(payload, function (data) {
    setLoader(false);
      if (data.status == "S") {
        props.setState({ activeStepForm: 6 });
        notification.success({
          message: data.message,
        });
        // props.setState({activeStepForm:5});
        // navigate("/verify-email?token=sdfsdfsdf56sdf5s6df5sd6f5sd6");
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  return (
    // <Main>

    <div className="container h-100">
      <div className="row h-100">
        <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
          <div className="CR-otp-form">
            <Spinner spinning={loader}>
              <Form
                form={form}
                onFinish={(values) => {
                  onCreateLead(values);
                }}
              >
                <ul className="row">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <h4 className="text-black">Create password</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-left">Create a new password for your Click2Remit account.</p>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <ul className="password-match">
                      <li className={props.charNumberValid ? "active" : "inactive"}>
                        At least 10 characters long
                      </li>
                      <li className={props.uppercaseValid ? "active" : "inactive"}>
                        At least 1 uppercase letter
                      </li>
                      <li className={props.lowercaseValid ? "active" : "inactive"}>
                        At least 1 lowercase letter
                      </li>
                      <li
                        className={
                          props.numberValid && props.specialCharValid ? "active" : "inactive"
                        }
                      >
                        At least 1 number or special character
                      </li>
                    </ul>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <CustomInput
                      // min={10}
                      // max={20}
                      showLabel={false}
                      name="passwords"
                      label="New Password"
                      type="password"
                      // required
                      validationRules={[
                        ({ getFieldValue }) => ({
                          validator(rule, value) {
                            let message = "";
                            let obj = checkPassword(value ? value : "");
                            message = obj.message;
                            if (obj.status === "S") {
                              return Promise.resolve();
                            }
                            return Promise.reject(message);
                          },
                        }),
                      ]}
                    >
                      <FloatInput
                        type="password"
                        placeholder="Create New Password"
                        onChange={handlePasswordChange}
                      />
                      {/* <FloatInput placeholder="Password" type="password"/> */}
                    </CustomInput>
                    {/* <div className="form-floating">
                      <input
                        type="email"
                        className="form-control"
                        id="floatingInput"
                      />
                      <label for="floatingInput">Password</label>
                      <i className="eye-close"></i>
                    </div>
                    <div className="error-text"></div> */}
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <CustomInput
                      validationRules={[
                        ({ getFieldValue }) => ({
                          validator(rule, value) {
                            if (!value || getFieldValue("passwords") === value) {
                              return Promise.resolve();
                            }
                            return Promise.reject("Password and confirm password must be same.");
                          },
                        }),
                      ]}
                      showLabel={false}
                      name="confirmpassword"
                      label="Confirm Password"
                      type="password"
                      required
                    >
                      <FloatInput type="password" placeholder="Confirm Password" />
                      {/* <Input.Password
                        className="float-input passwordinpt"
                        placeholder="Confirm Password"
                        type="password"
                      /> */}
                    </CustomInput>
                    {/* <div className="form-floating">
                      <input type="email" className="form-control" id="floatingInput" />
                      <label for="floatingInput">Confirm Password</label>
                      <i className="eye-open"></i>
                    </div>
                    <div className="error-text"></div> */}
                  </li>
                </ul>

                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-center ">
                    <div
                      className="Back_arrow d-flex align-items-center"
                      onClick={() => {
                        props.setState({ activeStepForm: 2 });
                      }}
                    >
                      <img src={BackArrow} alt="" /> Back
                    </div>
                    <button
                      htmlType="submit"
                      className="btn btn-primary CR-primary-btn"
                      style={{ width: "100px", margin: "0 !important" }}
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              </Form>
            </Spinner>
          </div>
        </div>
      </div>
    </div>

    // </Main>
  );
}
