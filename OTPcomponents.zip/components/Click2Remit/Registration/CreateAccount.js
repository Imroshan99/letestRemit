import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import CreateAccountStepper from "./CreateAccountStepper";
import CreatePersonalDetails from "./CreatePersonalDetails";
import Main from "../Layouts/Main";
import CreateResidentialDetails from "./CreateResidentialDetails";
import AddBeneficiaryDetails from "../Beneficairy/AddBeneficiaryDetails";
import CreateBeneficiaryResidentialDetails from "../Beneficairy/CreateBeneficiaryResidentialDetails";
import CreateBeneficiaryBankDetails from "../Beneficairy/CreateBeneficiaryBankDetails";
import CreateRemitterAccount from "../BankAccounts/CreateRemitterAccount";
import { useEffect, useReducer, useState } from "react";
import CreatePassword from "./CreatePassword";
import VerifyOtp from "../containers/VerifyOtp";
import VerifyEmail from "../containers/VerifyEmail";
import AccountCreatedSuccess from "./AccountCreatedSuccess";
import FindIfsc from "../Beneficairy/IFSC/FindIfsc";
import { useLocation } from "react-router-dom";
import { Form } from "antd";
import ReviewBeneficiaryDetails from "../Beneficairy/ReviewBeneficiaryDetails";
import BeneAddSuccess from "../Beneficairy/BeneAddSuccess";
import SelectRemitterAccount from "../BankAccounts/SelectRemitterAccount";
import ReviewRemitterAccountDetails from "../BankAccounts/ReviewRemitterAccountDetails";
import ManageRemitterAccounts from "../BankAccounts/ManageRemitterAccounts";
import { useSelector } from "react-redux";

export default function CreateAccount() {
  const [form1] = Form.useForm();
  const [form2] = Form.useForm();
  const [form3] = Form.useForm();
  const [form4] = Form.useForm();
  const [form5] = Form.useForm();
  const [form6] = Form.useForm();
  const [form7] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const location = useLocation();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    activeStepForm: 1,
    dob: "",
    personalDetails: {},
    residentialDetails: {},
    verificationToken: "",
    leadId: "",
    userPassword: "",
    beneficiaryDetails: {},
    beneficiaryResidentialDetails: {},
    beneficiaryBankDetails: {},
    beneBankAndAcctNo: {},
    beneBankName: "",
    beneficiaryBankCode: "",
    remitterAccountDetails: {},
    ifscBankCode: "",
    windowWidth: window.innerWidth,
    mobileView: false,
    stateForLocationData: "",
    proceedButtonBoolean: true,
    autofillRecv: {},
    cityLists: [],
  });
  const [password, setPassword] = useState("");
  const [charNumberValid, setCharNumberValid] = useState(false);
  const [specialCharValid, setSpecialCharValid] = useState(false);
  const [uppercaseValid, setUppercaseValid] = useState(false);
  const [lowercaseValid, setLowercaseValid] = useState(false);
  const [numberValid, setNumberValid] = useState(false);
  useEffect(() => {
    if (location?.state?.activeStepForm) {
      setState({ activeStepForm: location?.state.activeStepForm });
    }
    if (location?.state?.benificary) {
      setState({
        activeStepForm: location?.state?.benificary,
        stateForLocationData: location?.state?.benificary,
      });
    }
  }, []);
  useEffect(() => {
    if (state.activeStepForm > 6) {
      if (AuthReducer.isLoggedIn == "") {
        setState({ activeStepForm: 1 });
      }
    }
  }, [AuthReducer.isLoggedIn]);

  return (
    <Main sidebar={false}>
      <div class="row h-100 justify-content-center">
        <div
          class=" col-md-12 back-arrow-nav  d-xs-block d-done"
          style={{ padding: "0px 20px 0 20px !important" }}
        >
          <img src={BackArrow} alt="backarrow" />
        </div>
        {state.activeStepForm === 1 && (
          <CreatePersonalDetails form={form1} state={state} setState={setState} />
        )}
        {state.activeStepForm === 2 && (
          <CreateResidentialDetails form={form2} state={state} setState={setState} />
        )}
        {state.activeStepForm === 3 && (
          <CreatePassword
            charNumberValid={charNumberValid}
            setCharNumberValid={setCharNumberValid}
            specialCharValid={specialCharValid}
            setSpecialCharValid={setSpecialCharValid}
            uppercaseValid={uppercaseValid}
            setUppercaseValid={setUppercaseValid}
            lowercaseValid={lowercaseValid}
            setLowercaseValid={setLowercaseValid}
            numberValid={numberValid}
            setNumberValid={setNumberValid}
            password={password}
            setPassword={setPassword}
            form={form3}
            setState={setState}
            state={state}
          />
        )}
        {state.activeStepForm === 4 && <VerifyOtp setState={setState} state={state} />}
        {state.activeStepForm === 5 && <VerifyEmail />}
        {state.activeStepForm === 6 && <AccountCreatedSuccess />}
        {state.activeStepForm === 7 && (
          <AddBeneficiaryDetails form={form4} setState={setState} state={state} />
        )}
        {state.activeStepForm === 8 && (
          <CreateBeneficiaryResidentialDetails form={form5} setState={setState} state={state} />
        )}
        {state.activeStepForm === 9 && (
          <CreateBeneficiaryBankDetails form={form6} setState={setState} state={state} />
        )}
        {state.activeStepForm === 10 && <FindIfsc setState={setState} state={state} />}
        {state.activeStepForm === 11 && (
          <ReviewBeneficiaryDetails setState={setState} state={state} />
        )}
        {state.activeStepForm === 12 && <BeneAddSuccess setState={setState} state={state} />}

        {state.activeStepForm === 13 && (
          <CreateRemitterAccount setState={setState} state={state} form={form7} />
        )}
        {state.activeStepForm === 14 && (
          <ReviewRemitterAccountDetails setState={setState} state={state} />
        )}
        {state.activeStepForm === 15 && <SelectRemitterAccount setState={setState} state={state} />}
        {state.activeStepForm === 16 && (
          <ManageRemitterAccounts setState={setState} state={state} />
        )}
        {/* {!state.stateForLocationData && [1, 2, 7, 8, 9, 13].includes(state.activeStepForm) ? (
          <CreateAccountStepper state={state} setState={setState} />
        ) : (
          <></>
        )} */}
      </div>
    </Main>
  );
}
