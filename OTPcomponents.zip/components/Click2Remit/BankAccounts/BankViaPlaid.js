import { Button, Modal, notification, Radio, Spin } from "antd";
import { useEffect, useState } from "react";
import { PlaidLink } from "react-plaid-link";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { achBankAccountAPI } from "../../../apis/achBankAccountAPI";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { ViAmericaPlaidAPI } from "../../../apis/ViAmericaApi/PlaidAPI";
import useHttp from "../../../hooks/useHttp";
import addsvg from "../../../assets/images/click2remit/Add.svg";

const BankViaPlaid = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const [token, setToken] = useState(null);
  const [email, setEmail] = useState("");
  const [loader, setLoader] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [bankData, setBankData] = useState([]);
  const [selectedBnkData, setSelectedBnkData] = useState({});
  const hookCreateLinkToken = useHttp(ViAmericaPlaidAPI.createLinkToken);
  const hookLinkTokenExchange = useHttp(ViAmericaPlaidAPI.linkTokenExchange);
  const hookAddGetBankAccount = useHttp(ViAmericaPlaidAPI.addGetBankAccount);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookAddBankAccount = useHttp(achBankAccountAPI.addBankAccount);

  let location = useLocation();
  let navigate = useNavigate();
  useEffect(() => {
    createLinkToken();
  }, []);

  const getUserProfile = async (cb) => {
    let payload = {
      requestType: "USERPROFILE",
      userId: AuthReducer.userID,
    };
    setLoader(true);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        cb(data);
      }
    });
  };

  const createLinkToken = () => {
    getUserProfile(function (profileData) {
      setEmail(profileData.emailId);
      const payload = {
        requestType: "VIALINKTOKENCREATE",
        userId: AuthReducer.userID,
        emailId: profileData.emailId,
        loginToken: window.sessionStorage.getItem("loginTokenId"),
        idSenderGlobal: window.sessionStorage.getItem("idSenderGlobal"),
      };
      setLoader(true);
      hookCreateLinkToken.sendRequest(payload, function (res) {
        setLoader(false);

        if (res.status === "S") setToken(res.linkToken);
      });
    });
  };

  const onSuccess = (public_token, metadata) => {
    // send public_token to server
    console.log(public_token);
    console.log(metadata);

    exchangeLinkToken(public_token, metadata);
  };

  const exchangeLinkToken = (public_token, metadata) => {
    // setMessage("");

    const payload = {
      requestType: "VIALINKTOKENEXCHANGE",
      publicToken: public_token,
      userId: AuthReducer.userID,
      emailId: email,
      loginToken: window.sessionStorage.getItem("loginTokenId"),
      idSenderGlobal: window.sessionStorage.getItem("idSenderGlobal"),
    };
    setLoader(true);
    hookLinkTokenExchange.sendRequest(payload, function (data) {
      setLoader(false);
      // addBankAccountProfile(data, metadata, "GET");
      addBankAccountProfile(data, metadata);
    });
  };

  const addBankAccountProfile = (data, metadata, method = "POST") => {
    const requestData = {
      requestType: "VAIADDGETACCOUNTS",
      userId: AuthReducer.userID,
      emailId: email,
      loginToken: window.sessionStorage.getItem("loginTokenId"),
      idSenderGlobal: window.sessionStorage.getItem("idSenderGlobal"),
      accessToken: data.accessToken,
      itemId: data.itemId,
      accountId: metadata.account_id,
      method: method,
    };
    setLoader(true);
    hookAddGetBankAccount.sendRequest(requestData, function (res) {
      setLoader(false);
      if (res.status === "S") {
        if (res.bankResponse === "The account already exist") {
          getBankAccountProfiles(requestData);
          // alert("The account already exist");
          // props.setState({ activeStepForm: 7 });
        } else if (res.bankResponse === "Unable to find sender") {
          // notification.error({ message: "Unable to find sender" });
          // props.setState({ activeStepForm: 7 });
          alert("Unable to find sender");
        } else {
          const bankResponse = JSON.parse(res.bankResponse);
          bankResponse.accountid = metadata.account_id;
          bankResponse.accessToken = data.accessToken;
          addACHAccount(bankResponse);
          // alert("Account Linked Successfully.");
          // getBankAccountProfiles(requestData);
        }
      } else {
        notification.error({ message: res.errorMessage });
      }
    });
  };

  const getBankAccountProfiles = (requestData) => {
    requestData.method = "GET";
    setLoader(true);
    hookAddGetBankAccount.sendRequest(requestData, function (res) {
      setLoader(false);
      //   alert("Account Linked Successfully.");
      //   getBankAccountProfiles();
      const bankResponse = JSON.parse(res.bankResponse);
      setBankData(bankResponse);
      setIsModalVisible(true);
    });
  };

  const addACHAccount = async (data) => {
    let formData = {
      requestType: "addACHAccount",
      userId: AuthReducer.userID,
      routingNumber: data.routingNumber,
      nickname: data.idPayment,
      accountHolder: data.accountHolderName,
      bankName: data.bankName,
      accountNo: data.accountNumber,
      accountType: data.accountType,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
      processType: "ACH",
      idPayment: data.idPayment,
      accountid: data.accountid,
      public_token: data.accessToken,
    };
    setLoader(true);
    hookAddBankAccount.sendRequest(formData, function (res) {
      setLoader(false);
      setIsModalVisible(false);
      if (res.status === "S") {
        notification.success({ message: res.message });
        props.accountsList();
        if (location.pathname === "/create-account") {
          // props.setState({ activeStepForm: 7 });
          navigate("/new-transaction");
        } else if (location.pathname === "/manage-remitter-accounts") {
          if (location?.state?.autoFill) {
            navigate("/new-transaction", {
              state: {
                autoFillData: {
                  ...location?.state?.autoFillData,
                  sourceAccount: data.idPayment.toString(),
                },                
                autoFill: location?.state?.autoFill,
              },
            });
          } else {
            navigate("/manage-remitter-accounts");
          }
        }
        // if (props.state.redirectPage === "NEW_TRANSACTION") {
        //   navigate("/new-transaction", {
        //     state: props.state.redirectPageState,
        //   });
        // } else {
        //   navigate("/my-bank-accounts");
        // }
      } else {
        notification.error({ message: res.errorMessage });
      }
    });
  };

  const onExit = () => {};

  return (
    // <div className="BankViaPlaid">
    <div>
      <Spin spinning={loader}>
        <PlaidLink
          className="CR-blue-link CR-font-14 CR-fw-500 btn btn-link p-0 border-0"
          style={{ width: "200px !important", margin: "0 !important" }}
          token={token}
          onSuccess={onSuccess}
          onExit={onExit}
        >
          <img
            src={addsvg}
            width="16px"
            height="16px"
            className="me-2"
            alt="ADD NEW REMITTER ACCOUNT"
          />{" "}
          ADD NEW REMITTER ACCOUNT
        </PlaidLink>
        <Modal
          className="CR_jumio_modal"
          width={500}
          open={isModalVisible}
          footer={null}
          // onOk={handleOk}
          onCancel={() => setIsModalVisible(false)}
        >
          <div className="w-100">
            <Radio.Group
              className="d-flex flex-column"
              onChange={(e) => {
                setSelectedBnkData(e.target.value);
              }}
            >
              {bankData?.map((i) => {
                return (
                  <Radio value={i}>
                    <div className="d-flex justify-content-between flex-column w-100">
                      <label className="CR-font-14 CR-black-text CR-fw-600 text-left mb-1">
                        {i.accountHolderName}
                      </label>
                      <p className="CR-font-12 text-left CR-fw-500 mb-0">
                        {i.bankName} <span>&#8226;</span> {i.accountNumber}
                      </p>
                    </div>
                  </Radio>
                );
              })}
            </Radio.Group>
            <div className="w-100 d-flex justify-content-end">
              <Button onClick={() => addACHAccount(selectedBnkData)}>OK</Button>
            </div>
          </div>
        </Modal>
      </Spin>
    </div>
  );
};

export default BankViaPlaid;
