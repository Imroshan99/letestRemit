import React from "react";
import { Link } from "react-router-dom";
import Main from "../Layouts/Main";

const DeleteMsg = () => {
  return (
    <Main>
      <div className="modal  fade show" tabindex="-1">
        <div className="modal-dialog-centered " style={{ margin: "0 auto", maxWidth: "500px" }}>
          <div className="modal-content">
            <div className="modal-body p-4">
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <h5>Delete remitter account?</h5>
              <p>Are you sure you want to delete this remitter account?</p>
              <div className="align-items-center btn-modal-wrapper">
                <Link className="CR-black-text me-4">CANCEL</Link>
                <Link className="CR-primary-btn align-items-center d-flex justify-content-center rounded-pill CR-min-width-100px">
                  DELETE
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show"></div>
    </Main>
  );
};

export default DeleteMsg;
