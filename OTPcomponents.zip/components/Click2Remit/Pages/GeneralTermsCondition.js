import { Link } from "react-router-dom";
import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";

export default function GeneralTermsCondition() {
  return (
    <div className="GeneralTermsCondition">
      <table width={600} border={0} align="center" cellPadding={0} cellSpacing={0}>
        <tbody>
          <tr>
            <td
              align="center"
              valign="top"
              style={{
                borderTop: "1px solid #656565",
                borderBottom: "1px solid #656565",
                borderLeft: "1px solid #656565",
                borderRight: "1px solid #656565",
              }}
            >
              <table border={0} align="center" cellPadding={0} cellSpacing={0}>
                <tbody>
                  <tr>
                    <td
                      align="center"
                      valign="top"
                      className="outerpadding"
                      style={{ paddingTop: 20 }}
                    >
                      <table width={560} border={0} align="center" cellPadding={0} cellSpacing={0}>
                        <tbody>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{ paddingBottom: 20, textAlign: "left" }}
                            >
                              <img
                                src={c2r_logo}
                                width="300px"
                                height="58.9px"
                                style={{ display: "block !important" }}
                                className="toplogo1"
                                border={0}
                              />
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td align="center" valign="top" className="outerpadding" style={{}}>
                      <table width={560} border={0} align="center" cellPadding={0} cellSpacing={0}>
                        <tbody>
                          <tr>
                            <td align="center" valign="top" style={{}}>
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Following are the terms, conditions and rules ("T &amp; C"),
                                      subject to which the Visitor/Registered User as defined below
                                      can avail remittance services offered by Bank’s Alliance
                                      Partners in the respective Jurisdiction where the
                                      Visitor/Registered User reside to send money to their own
                                      accounts in India or to any other persons account in India
                                      (“Facility”) as defined below. These T &amp; C are applicable
                                      only to the extent of registering a Visitor by collecting
                                      their name, address, email id &amp; phone number on the
                                      Click2Remit (C2R) Platform of Kotak Mahindra Bank Ltd (Bank)
                                      and the cross-border money transfer will be completed by its
                                      Alliance Partners. The Terms &amp; Conditions for availing the
                                      cross-border money transfer Facility offered by the Alliance
                                      Partners shall be displayed upon selecting the geographical
                                      location where the Visitor/Registered User reside. Alliance
                                      Partners shall be exclusively responsible for executing the
                                      transaction pertaining to the Remittance Services and the Bank
                                      shall be no way responsible for the same.{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Product, deposit accounts, Nostro account, lines of credit,
                                      trade finance activities, clearance and collections activity,
                                      etc., that may be appearing elsewhere on this Website as
                                      defined below or otherwise now or hereafter agreed or deemed
                                      to be agreed to by the Registered User. The T &amp; C may be
                                      read as a stand-alone document or may be read with such other
                                      documents as may apply to a particular service, situation,
                                      circumstance, or transaction.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      The Visitor/Registered User acknowledges and agrees that the
                                      Bank may at its sole discretion add to, modify or amend the T
                                      &amp; C (including the Charges) from time to time without any
                                      prior notice. Unless otherwise specified by Bank, all
                                      additions, modifications or amendments shall take effect and
                                      be binding on and from the day they are posted on the Website.
                                      Before accessing or using the Website or Facility, Visitor or
                                      Registered User should review the T &amp; C for any additions,
                                      modifications or amendments. If the Visitor does not agree to
                                      the alterations, additions or deletions to the T &amp; C or
                                      disagrees with any material on the Website, the Visitor or
                                      Registered User should discontinue accessing or using the
                                      Website or any Facility (other than those which have already
                                      been availed of prior to such alterations, additions or
                                      deletions). By continuing to access or use the Website or any
                                      Facility offered on the Website, the Visitor or Registered
                                      User will be deemed to have agreed to accept and be bound by
                                      such modified T &amp; C.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      The Visitor/Registered User agrees that the Bank is required
                                      to abide by the rules and regulations of the government or
                                      self-regulatory bodies by which the Bank is governed and/or to
                                      which the Bank is or maybe affiliated and the Registered User
                                      may also be required to abide such rules and regulations.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      The Registered User agrees that in addition to the applicable
                                      rules and regulations introduced or amended from time to time
                                      by the Reserve Bank of India (“RBI”), availing the Facility is
                                      subject to the applicable law, rules and regulations in USA.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      The Visitor/Registered User must accept and agree to abide by
                                      the T &amp; C before accessing or using the Website or the
                                      Facility. In the event that these T &amp; C are not
                                      acceptable, the Visitor/Registered User shall not access or
                                      use this Website or any pages thereof and shall not use the
                                      Facility.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      By clicking on "I Agree" it will be deemed that the user has
                                      read, understood, and accepted to abide by the T &amp;C and
                                      agrees to be redirected to the T &amp; C applicable to the
                                      Money Transfer Services pertaining to the jurisdiction where
                                      the Visitor/Registered User resides.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      DEFINITIONS
                                      <br />
                                      All the capitalised words and phrases have the meaning stated
                                      hereunder unless indicated otherwise or as defined below:
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Alerts" mean messages relating to various matters
                                      electronically sent to the Registered User, which are
                                      triggered by occurrence of certain events in respect of the
                                      Facility.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Alliance Partner" means any person (other than Bank)
                                      including Correspondent Bank or who displays content or offers
                                      any Facility on the Website.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Assistance Via Phone" means the assistance that may be
                                      provided, at the discretion of the Bank, either by itself or
                                      through a Service Provider over the phone, in connection with
                                      the Website and the Facility and/or any transactions entered
                                      into or proposed to be entered into by the Visitors/Registered
                                      User in respect of such Facility.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Bank" shall mean Kotak Mahindra Bank Limited, which is an
                                      Indian company incorporated under the Companies Act, 1956, and
                                      licensed as a bank under the Banking Regulation Act, 1949,
                                      having its registered office at 27 BKC, C 27, G Block, Bandra
                                      Kurla Complex, Bandra (E), Mumbai - 400 051, and its branches,
                                      their successors and assigns.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Beneficiary" means the individual person situated in India to
                                      whom or to whose account the funds are remitted through the
                                      Facility, through any of the modes specified, by the
                                      Registered User or in whose favour the demand draft is issued
                                      through the Facility by the Registered User.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      C2R shall mean the application/portal developed by the Bank
                                      which redirects the Users who request for availing the
                                      Facility offered by Alliance Partners Money Transfer Platform
                                      post registering them by providing their name, address, email
                                      id, and phone number.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Correspondent Bank" means and includes other banks which
                                      extend to the Bank certain services including but not limited
                                      to maintenance of a nostro account, extending lines of credit,
                                      facilitating undertaking of trade finance activities,
                                      extending clearance and collections activity; and also
                                      includes other banks or any company which extends its
                                      facilities to the Bank to provide Facility to the Registered
                                      Users, whether in India or abroad.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      "Facility" includes the remittance services offered by
                                      Alliance Partners through a web enabled technology platform
                                      called Money Transfer Platform, at the sole discretion of
                                      Alliance Partners, to all or some of the Registered User or
                                      Registered User located in specified locations, to remit money
                                      to Beneficiaries in India through using the modes specified by
                                      the Bank from time to time including but not limited to:
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Bank Transfer (Net Banking)
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Wire Transfer
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      To create a Term Deposit in India with the Bank or
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      For any other specified purpose as may be indicated by the
                                      Bank from time to time.
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Delivery Modes - Remittances can be delivered to Beneficiaries
                                      in India through the following modes:
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    >
                                      Direct credit to the Bank account
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 12,
                                      }}
                                    ></td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Direct credit to Other bank accounts in India through Interbank
                              transfer
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Demand Draft Delivery
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Credit Card Payments via NEFT
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Facility includes following facilities made available at the sole
                              discretion of the Alliance Partner to all or some of the Registered
                              User located in specified locations, such as:
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Tracking the status of remittance from time to time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              {" "}
                              Reminder facility which provides the Registered User with the option
                              of setting Alerts for reminding the Registered User of some festive
                              seasons or personal/family occasions (or any other dates) on which the
                              Registered User could affect the remittance.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              "Force Majeure” includes fortuitous event, fire, floods, storm,
                              explosions, earthquake or any other acts of God, any acts of the
                              government/semi-governmental/local authority including laws, decrees,
                              ordinances and governmental regulations affecting the business of the
                              Bank, civil disturbances, wars, war like situations, terrorism, riots
                              and insurrections, acts of public enemy, strikes and lockouts,
                              transportation stoppages or slowdowns.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Money Transfer Platform shall mean the money transfer application
                              and/or website developed in association with Alliance Partners that
                              enables Users to access Remittance Services.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              "Registered User" means any Visitor who has registered on C2R portal
                              of the Bank by providing their name, address, mobile number, and email
                              id to avail of the Facility.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              "Registered User ID" / “User ID” shall mean the email ID of the
                              Registered User chosen by them and registered with the Website for
                              access to the Website and availing of the Facility. The Registered
                              User is entitled to have only one User ID at any given point of time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              "Registered User Password" / “Password” means the password that is
                              chosen by the Registered User and registered with the Website for
                              access to the Website and availing of the Facility. The Registered
                              User is entitled to have only one Password at any given point of time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “Service Provider” means any person (not an Alliance Partner), who
                              provides a service to Bank to enable the Bank to operate and/or
                              maintain the Website, provide any feature thereon or provide any
                              Facility.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “T &amp; C” shall mean Terms and Conditions relating to registering
                              the Visitor/User on C2R portal for availing the Facility as may exist
                              now and as may be amended from time to time and includes all rules and
                              regulations prescribed by the Reserve Bank of India (“RBI”) and any
                              other authority from time to time and all terms and conditions
                              relating to each banking product/service as may exist now and as may
                              be amended from time to time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “Technical Snags” includes any problems and difficulties arising due
                              to routine maintenance requirements, excess demand, power and
                              electricity failure, computer errors, programming errors, software or
                              hardware errors, computer breakdown, Internet or network failure,
                              faults in the telecommunications network, non-availability of Internet
                              connection, communication problems between the Bank's server and
                              Visitor/Registered User's computer network, shutting down of the
                              Bank's server or Website, non-availability of communication links,
                              corruption of the computer software, snags in the service providers
                              infrastructure and telecommunication network, and arising due to any
                              other technology related snags; any problems and difficulties for any
                              reasons whatsoever including but not limited to natural calamity,
                              floods, fire and other natural disasters, legal restraints or any
                              other problem or difficulty beyond the control of the Bank.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              "Visitor" means any person who accesses or visits the Website, whether
                              or not such person has registered as a Registered User, and includes
                              every Registered User.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “Website” means the website of the Bank and includes the pages of the
                              Website and any applets, software, and content contained in the
                              Website including the C2R portal.{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “Supplier” means who acts as an agent on behalf of the bank to provide
                              verification services.{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              “Overseas Bank” means customers overseas own bank through which the
                              funds’ transfer originated.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              WEBSITE
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Website primarily facilitates the display and offering of the
                              Facility on a no-liability and no-obligation basis. Information and
                              Facility may be displayed and offered in a phased manner at the
                              discretion of the Bank. Bank may at its sole discretion, introduce new
                              information to the Facility and add to, modify, suspend, or withdraw
                              any information or Facility or any terms thereof in whole or in part
                              without any prior notice.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank has the right (but not an obligation) to monitor the
                              functioning of the Website from time to time and to disclose any
                              information as necessary or appropriate to satisfy any law,
                              regulation, or other governmental requests, to operate the Website or
                              to protect itself or its Service Providers, Alliance Partners,
                              Correspondent Banks, or Visitors/Registered Users.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              ELIGIBLE USERS
                              <br />
                              Only individual visitors shall be eligible to register themselves on
                              the C2R portal to avail of the cross-border money transfer facility
                              offered by Alliance Partners. Bank is not attempting to offer or
                              provide facilities to any other persons or entities.{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User must be of at least 18 years of age, of sound
                              mind, and otherwise eligible to enter legally binding contracts under
                              applicable law. If the Visitor does not qualify to be the Registered
                              User, they should immediately cease to access or use the Website or
                              the Facility.{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Facility shall be made available only to the approved Registered
                              User. The Bank reserves the right to approve or reject the application
                              for any Visitor. The Registered User hereby agrees that the Registered
                              User shall not have more than one (1) User ID and/or Password.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              For a Visitor to use the Facility, the Registered User shall agree to
                              other terms and conditions in addition to these T &amp; C and may also
                              have to execute agreements, powers of attorney and other writings and
                              abide by the procedures, in the manner prescribed by the Bank.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              ACCESS
                              <br />
                              Only limited access to the Website is available to Visitors who are
                              not Registered Users. To obtain increased access to the Website and in
                              order to make full use of the C2R portal the Visitor is required to
                              register on the Website as a Registered User.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              REGISTERED USER ID AND PASSWORD
                              <br />
                              At the time of registration for the Facility the Registered User shall
                              select and set their own User ID and User Password.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              PROCEDURE FOR CREATING THE PASSWORD
                              <br />
                              The Registered User shall be required to create a Password.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User is then required to enter answers for 3 hint
                              questions. This is so that in case the Registered User forgets the
                              Password, any one of these questions must be answered to regenerate
                              the Password. Registered User agrees and acknowledges that he shall be
                              solely responsible for maintaining the secrecy of the User ID and
                              Password.{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Registered users must comply with any other requirements indicated by
                              the Bank to protect the system’s security through which the Registered
                              User accesses/uses the Website/C2R portal. The Registered User agrees
                              and accepts that in the event of any loss or damage incurred by the
                              Registered User by reason of sharing/compromise of the password, the
                              Registered User shall be solely responsible for the consequential loss
                              or damage, and the Bank shall not be held responsible or liable for
                              the same.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              To ensure that the Registered User alone is able to access and place
                              request for availing the Facility through the Website/C2R portal, the
                              Registered User must all times comply with the following security
                              procedures:
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      width={19}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      1.{" "}
                                    </td>
                                    <td
                                      width={541}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      Change of User ID/Password regularly or as required by the
                                      Bank;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      2.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      not choose a User ID/Password, which the Registered User has
                                      used before or which is likely to be guessed by anyone;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      3.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      safeguard the User ID/Password at all times and not disclose
                                      any details of the User ID/Password to anyone else including a
                                      member of the Bank staff;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      4.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      not record User ID/Password in a way whereby it will be
                                      legible or accessible to any third party;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      5.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      memorise User ID/Password and destroy any record of it;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      6.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      not allow anyone to access C2R portal on Registered User's
                                      behalf; (vii) not leave any system unattended while logged on
                                      to the Website/Facility and log-out from the Website/C2R
                                      portal when not using the Website/Facility;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      7.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      not access the Website/C2R portal from any equipment or device
                                      connected to a local area network (or LAN), such as an office
                                      environment, without first ensuring that no one else is able
                                      to observe or copy the User ID/Password. The Registered User
                                      shall indemnify the Bank if any loss is suffered by the Bank
                                      due to failure to comply with the above security procedures.
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              If the Registered User discovers or suspects that the User ID/Password
                              or any part of them is known to someone else, the Registered User must
                              immediately change the User ID/Password through the Website. If this
                              is not possible, the Registered User must notify the Bank immediately
                              through the phone banking service or Assistance Via Phone. The
                              Registered User agrees and acknowledges that the Bank can take the
                              necessary steps only on the next business day as per the Indian
                              Standard Time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Loss of User ID/Password: If the Registered User forgets or loses the
                              User ID/Password a new User ID/Password will be selected and set by
                              the Registered User through the Website if the Registered User
                              correctly responds to the hint questions. However, the Registered User
                              shall be responsible and liable for all transactions carried out using
                              the old Password until the Bank has received notification from the
                              Registered User that the old password has been compromised. The Bank
                              shall not be liable for any consequences if Bank and/or Website
                              declines to furnish the new User ID/Password by reason of it not being
                              satisfied as to the Registered User's identity.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any transaction or activity originated by use of the User ID and/or
                              Password shall be deemed to be the transaction or activity originated
                              by the Registered User and the Bank shall not be required to verify
                              the authenticity of any such transaction or activity or origination of
                              the same. The Bank shall not be responsible for any mistake or error
                              made by the Registered User in keying in the nature of the
                              transaction/activity or any facts or figures.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Notwithstanding anything stated elsewhere in the T &amp; C and despite
                              the correct use of the User ID/Password, the Bank may in its sole
                              discretion (but shall not be bound) seek offline and/or additional
                              written or other confirmation from the Registered User of any
                              instruction, transaction or activity.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank reserves the right and discretion to permit the use of
                              digital signatures using the Public Key Infrastructure System as
                              provided for under the Information Technology Act, 2000 (or other
                              applicable law), as per Bank's policy or as and when the law
                              authorises and technology facilitates such use. In such an event the
                              Bank shall have the right to require the Registered User to
                              communicate instructions and authorise and execute transactions and
                              other activities by means of such secure electronic records and secure
                              digital signatures in addition to or in place of, the use of
                              Password(s) and the Registered User shall do all such acts as may be
                              required to access the Facility.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              REPRESENTATION AND WARRANTIES OF THE VISITOR/REGISTERED USER
                              Visitor/Registered User represents and warrants that:
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      width={19}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      1.{" "}
                                    </td>
                                    <td
                                      width={541}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      the Registered User has the authority and/or is lawfully
                                      entitled to accept the T &amp; C and is not under any
                                      disability, restriction, or prohibition which shall prevent
                                      the Registered User from performing or adhering to any
                                      obligations under the T &amp; C;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      2.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      the execution of the T &amp; C or any part therein is not,
                                      directly or indirectly, in conflict with any other agreement
                                      or document that the Registered User has executed or entered
                                      into;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      3.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      there are no liabilities against, relating to, or affecting
                                      the Registered User, which individually or in the aggregate,
                                      are material to the business of the Bank;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      4.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      the personal information provided by the Registered User to
                                      the Bank at the time of registration is true and accurate and
                                      any other information provided thereafter shall be true and
                                      accurate; or
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      5.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      there are no legal proceedings, or injunctive or stay orders
                                      pending against or likely to arise against the Registered User
                                      that may violate the T &amp; C or materially affect the
                                      fulfillment of these T &amp; C.
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              CONDUCT OF VISITORS, REGISTERED USERS
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Visitor/Registered User shall not:
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      width={19}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      1.{" "}
                                    </td>
                                    <td
                                      width={541}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      make any attempt to hack into the Website or otherwise attempt
                                      to subvert any firewall or other security measure of the
                                      Website and if the Visitor/Registered User becomes aware of
                                      any shortcoming in the security on the Website the
                                      Visitor/Registered User shall forthwith inform Bank of the
                                      same;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      2.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      restrict or inhibit any other person from accessing, or using
                                      the Website/Facility;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      3.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      use the Website for any unlawful purpose;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      4.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      post or transmit any libelous, defamatory, obscene,
                                      pornographic, fraudulent, threatening, hateful, offensive, or
                                      otherwise illegal, unlawful, or objectionable information or
                                      statement of any kind;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      5.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      post or transmit any advertisements, solicitations, chain
                                      letters, pyramid schemes, investment opportunities or schemes,
                                      or other unsolicited commercial communication (except as
                                      otherwise expressly permitted by the Bank) or engage in
                                      spamming or flooding; or
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      6.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      post or transmit any information or software which contains
                                      viruses or other harmful components.
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              GENERAL TERMS FOR PLACING A REQUEST FOR THE FACILITY
                              <br />
                              It shall be the sole responsibility of the Visitor/Registered User to
                              verify whether the Website and the C2R portal can be legally accessed,
                              and Facility can be availed in their respective jurisdictions.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank will endeavor to facilitate the Visitor/Registered user to access
                              the cross-border money transfer facility offered by its Alliance
                              Partners. However, Bank will not be responsible or liable for
                              non-provision of any Facility or any part thereof, changes in the time
                              schedule, or delays in remittance or execution of the Registered
                              User's instructions for any reason including due to the act or
                              omission of Alliance Partner or the Correspondent Bank or due to
                              incorrect information provided by the Visitor/Registered User. The
                              Registered User should use the Facility provided by its Alliance
                              Partners only if the Registered User is agreeable to the above. The
                              usage of the Facility shall be deemed acceptance of this condition.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User hereby agrees that Bank has no control over when
                              the Beneficiary's financial institution makes such funds available for
                              the Beneficiary's use and the Bank shall not be responsible for any
                              delay or default on the part of such financial institution.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User hereby agrees that, where Bank so deems advisable
                              or necessary, Bank may hold back or delay the remittance of funds for
                              a period longer than the time required for remittance in the usual
                              course of business. The Bank shall not be liable for any loss or
                              damage that may be suffered by the Registered User or any third party
                              due to such delay.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              While the Bank endeavors to post accurate and updated information on
                              the Website, the Registered User shall verify the same before taking
                              any action or entering into any transaction.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User may be required to provide such information as may
                              be indicated by the Bank. The Registered User is responsible for the
                              correctness of information supplied to the Bank. The Bank shall have
                              the right to, and the Registered User hereby authorises Bank (by
                              itself or through third parties) to verify any information provided by
                              the Registered User. If the Registered User has reason to believe that
                              there is an error in the information furnished to the Bank, the
                              Registered User shall immediately advise the Bank in the manner
                              indicated by the Bank. The Bank shall not be liable for any
                              consequences arising from erroneous misleading, incorrect, untimely,
                              or incomplete information furnished by the Registered User.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User agrees that the Bank shall levy such charges as
                              may be indicated by the Bank on the website/C2R portal. The Bank
                              charges shall not include the remittance charges, if any, levied by
                              the remitter overseas bank.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              If the Registered User chooses to have the charges deducted from the
                              account with the Bank but does not have an account with the Bank or
                              there are insufficient funds in the said account, then the charges
                              will be debited from the remittance amount and the Registered User
                              hereby gives his consent for the same.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank may levy charges in respect of the issuance of the Foreign
                              Inward Remittance Certificate (FIRC) or any other proof of remittance
                              to the Beneficiary.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank at its sole option and discretion shall maintain or destroy or
                              cause to be maintained by Bank through its or a third party's computer
                              systems or on tape or other recording or storage device or otherwise
                              such records of access, instructions, transactions in respect of the
                              Facility and other activities, as the Bank may deem fit or as mandated
                              by applicable law.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank shall be entitled, in its sole and absolute discretion, to refuse
                              to comply with all or any of the instructions received from the
                              Registered User without assigning any reason. The Bank shall not be
                              liable for any loss or damage that may be caused to the Registered
                              User or any third party due to such refusal.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User cannot cancel any instructions once communicated,
                              except as specifically provided on the Website. Such instructions or
                              transactions will only be cancelled if the Registered User's request
                              for cancellation is received and acted upon before the instruction or
                              transaction has been executed, if the funds have not been passed on to
                              the Beneficiary, and are still in the control of the Bank on best
                              effort basis.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              In case of transaction reversals/returns for any mode of delivery,
                              Bank personnel shall use commercially reasonable efforts to contact
                              the Registered User and the Registered User will be requested to
                              provide modified instructions for the transaction in question.
                              However, if the Registered User cannot be contacted and/or the Bank
                              does not receive modified fresh remittance instructions for the
                              transaction in question, the Bank shall have the right to send the
                              funds back to the Registered User's remitting account after deducting
                              any applicable reversal/return charges.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Registered User must take all reasonably practicable measures to
                              ensure that the Registered User's system or any computer or other
                              equipment or device from which the Registered User accesses the
                              Facility is free of any computer virus or similar software/device
                              including, without limitation, devices commonly known as software
                              bombs, Trojan horses and worms (“Viruses”) and is adequately
                              maintained and secured in every way.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              {" "}
                              Though the Bank will take steps to prevent the introduction of Viruses
                              and other such destructive materials on the Bank's Website, it does
                              not represent, warrant, or guarantee that the Bank's Website or the
                              content downloaded from the Bank's Website or linked Websites do not
                              contain such Virus or destructive materials. Bank is not liable for
                              any damage or harm attributable to such virus or destructive
                              materials. The Bank does not warrant that the Bank's Website or
                              functions thereof will be uninterrupted or free of any error or
                              defect.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Exchange Rate Terms and Conditions:
                              <br />
                              The terms and conditions pertaining to Exchange Rate are as set out by
                              its Alliance Partners provided in their Terms and Conditions.
                              Visitors/Registered Users are required to read the T &amp; C of the
                              Alliance Partners which will be displayed while carrying out
                              cross-border remittance and shall accept the same prior to carrying
                              out every single transaction, the bank shall not be responsible for
                              the same.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank shall in no way be held responsible and/or be liable for any
                              queries, errors, disputes, or delays in messaging, money transmission,
                              currency conversion, conversion rates offered, payment to the
                              beneficiaries of the remittances, or any other query, claim, or
                              dispute. The Registered User may contact the Bank Customer Care Unit
                              to facilitate the resolution of such queries, claims, and disputes to
                              the best of the Bank's ability.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank may have more than one promotional offer in existence and
                              applicable at any given time. However, a customer shall be entitled to
                              only one offer per transaction. It shall be entirely at the discretion
                              of the Bank to consider any exceptions to the above.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User will not be entitled to any interest for the
                              period during which the funds to be remitted are with Bank, pending
                              remittance or are in the course of remittance, or for any other
                              period.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Visitor/Registered User hereby authorises Bank to check his or her
                              credit history at the time of and/or prior to or subsequent to
                              registration and to obtain follow-up credit reports relating to him.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User hereby agrees that the purpose of the remittances
                              will be strictly for personal, family, or household use. Trade or
                              business-related remittances or remittance for the purchase of
                              property or investment and other remittances not permissible under
                              applicable law are not permitted and should not be effected through
                              the Facility.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User confirms that the remittances are not meant for
                              any purpose which is in conflict with any law in India, or elsewhere.
                              The Registered User hereby agrees and undertakes that he shall not
                              utilise the Facility for remitting any funds, which are obtained by
                              illegal means or which are to be used for illegal purposes or the
                              purpose of money laundering.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank and/or its Service Providers shall endeavor to ensure that Alerts
                              are communicated to the Registered User where the Registered User has
                              agreed to receive such Alerts. However, neither Bank nor the Service
                              Providers would be responsible nor liable for non-dispatch or delay in
                              dispatch of the Alerts by the Bank and/or the Service Providers or any
                              delay in receipt or non-receipt of the Alerts for any reason
                              whatsoever. Bank and/or the Service Providers shall not be liable for
                              any costs, damages, or other amounts whatsoever for such non-dispatch
                              or delay in dispatch or any non-receipt or delay in receipt of the
                              Alerts. Non-receipt of Alerts will not discharge or reduce the
                              Registered User's liability to pay any amount to the Bank which would
                              have been payable in the event of proper receipt of the Alerts.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              INTELLECTUAL PROPERTY
                              <br />
                              The Bank is the owner and/or authorised user of any trademark,
                              registered trademark, and/or service mark appearing on the Website.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Visitor/Registered User acknowledges and agrees that all the
                              intellectual property rights in the software underlying the Website,
                              the C2R portal, and other software required for accessing or using the
                              Website/C2R portal are the property of the Bank or its respective
                              vendors. The permission given by the Bank to access and use the
                              Website or C2R portal shall not convey any rights in the intellectual
                              property of the software. The Visitor/Registered User shall not
                              attempt to modify, translate, disassemble, decompile, or reverse
                              engineer the above-mentioned software or copy the source code of the
                              software or create any derivative product based on the software.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Visitor/Registered User shall use any software provided on, by, or
                              through the Website only for the purposes it has been provided and for
                              no other purpose.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank is the owner or licensee of the content and/or information on
                              the Website including but not limited to any text, images,
                              illustrations, and screens appearing on the Website. The
                              Visitor/Registered User may not download and/or save a copy of the
                              Website or any part thereof including any of the screens or part
                              thereof and/or reproduce, store it in a retrieval system, or transmit
                              it in any form or by any means - electronic, electrostatic, magnetic
                              tape, mechanical printing, photocopying, recording or otherwise or
                              translate the same without the express permission of Bank (except as
                              otherwise provided on the Website or in the T &amp; C for any purpose)
                              or use it in any manner that is likely to cause confusion or deception
                              among persons or in any manner disparages or discredits Bank, Alliance
                              Partners, Correspondent Bank or Service Providers. However, the
                              Registered User may print a copy of the information on the Website for
                              the Registered User's personal use or records.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              CONFIDENTIAL INFORMATION
                              <br />
                              The Visitor/Registered User acknowledges and agrees that the
                              Visitor/Registered User has read the Privacy Policy published on the
                              Website and hereby confirms such agreement to the terms stated
                              therein.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank will not intentionally monitor or disclose any private
                              electronic-mail message received through the Website to any third
                              party unless required by law.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User hereby agrees that the Bank shall be entitled to
                              inform any credit bureau or any other person or entity if the
                              Registered User fails to pay/reimburse any amount due to the Bank.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank shall endeavor to take reasonable measures, which may include
                              encryption, to ensure that the Registered User's personal information
                              is not disclosed to any person except to the Bank, Alliance Partners,
                              Service Providers, other persons to whom the information may be
                              provided as per Bank's Privacy Policy and other persons specified by
                              the Registered User. However, the Internet is an open system and Bank
                              cannot, and does not, guarantee that the personal information, which
                              the Registered User furnishes, will not be intercepted or accessed by
                              others and decrypted. The Bank, the Alliance Partners, and Service
                              Providers shall not be liable or responsible should any confidential
                              or other information provided by or pertaining to the Registered User
                              (including credit card numbers, bank account numbers, passwords,
                              personal identification numbers, IDs, transaction details, etc.) be
                              intercepted and subsequently used by an unintended recipient.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              INDEMNIFICATION
                              <br />
                              The Visitor/Registered User agrees to and shall indemnify and hold the
                              Bank and each of the employee agents, consultants contractors, content
                              providers or representatives of the Bank harmless against all actions,
                              claims, liabilities, demands, proceedings, losses, damages, costs,
                              charges and expenses including reasonable attorneys' fees and
                              court/adjudicating body costs whatsoever, which the Bank may at any
                              time incur, sustain, suffer or be put to as a consequence of or by
                              reason of or arising out of:{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      width={19}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      1.{" "}
                                    </td>
                                    <td
                                      width={541}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      breach of the Visitor/Registered User‘s representations and
                                      warranties;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      2.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      improper use of the Click2Remit portal by the
                                      Visitor/Registered User or any other person with its consent;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      3.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      breach by Visitor/Registered Use or any other person with his
                                      consent of any of the provisions of the T &amp; C or any other
                                      agreement with the Bank; or,
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      4.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      the Bank in good faith taking or refusing to take action on
                                      any instruction given by the Visitor/Registered User due to
                                      acts or omissions of the Visitor/Registered User, including
                                      but not limiting to:
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (a) Failure to intimate/inform the Bank when it suspects or
                                      knows that its Passwords are known to third parties or when
                                      third parties use its Passwords for carrying out unauthorised
                                      or illegal transactions;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (b) Failure to keep confidential and secure the Passwords from
                                      third parties;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (c) Failure to inform the Bank regarding any changes in its
                                      personal information;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (d) Unauthorised or illegal access to the computer
                                      system/network and/or data of the Bank by using
                                      Visitor/Registered User's Passwords;{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (e) Failure to comply with the governing law and law of the
                                      country of residence;
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (f) Failure to comply with the usage guidelines issued by the
                                      Bank in respect of the Click2Remit portal as may be applicable
                                      at the relevant time; and{" "}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      &nbsp;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      (g) Failure to comply with these T &amp; C and any agreement
                                      between the Bank and the Visitor/Registered User.
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank shall not be responsible or liable for any consequences
                              arising out of the abovementioned situations.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              LIMITATION OF LIABILITY
                              <br />
                              Bank shall not, under any circumstances, be responsible for any loss
                              suffered due to any fraud or other actions of the Registered User or
                              any third party.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank shall take all care to provide secure and error-free services
                              to its Visitor/Registered User on best effort basis. The Bank shall
                              not be liable or responsible for any damages, loss, harm, expense,
                              liability, and the like arising to the Visitor/Registered User or any
                              third party for any reasons whatsoever whether attributable to the
                              Bank or not.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Without prejudice to the above, the Bank shall not be liable to the
                              Visitor/Registered User or any third party for any loss or damage
                              suffered due to the following reasons: Any action carried on by the
                              Bank in good faith, based upon the instructions of the
                              Visitor/Registered User, by exercising due diligence, in good faith or
                              taking reasonable care; Any unauthorised and illegal transactions
                              occurring through the use of the Facility which can be attributed to
                              the fraudulent or negligent conduct of the Visitor/Registered User
                              and/or any third party; Intrusion or hacking into the computer
                              systems/network or communication network of the Bank; Failure to carry
                              out any instructions of the Visitor/Registered User due to
                              insufficiency of balance in his account; Failure of the
                              Visitor/Registered User to inform the Bank when the Facility is
                              illegally availed of by third parties for carrying out any
                              transaction; Failure of the Visitor/Registered User to keep
                              confidential and secure, any User ID/Passwords; Failure to provide or
                              provision of inaccurate, incorrect information by the
                              Visitor/Registered User whether personal or in respect of any account
                              or Facility; Any cancellation instructions not being/not being carried
                              out or any delay thereof; Violation of any applicable law or breach of
                              any of the T &amp; C by the Visitor/Registered User or any other
                              person with/without the consent of the Visitor/Registered User; or any
                              cause arising out of or related to Force Majeure or Technical Snags or
                              for any reasons beyond the reasonable control of the Bank.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              In the event that the Bank is held liable for any loss or damage to
                              the Visitor/Registered User as a result of the use of any Facility
                              provided by its Alliance Partners, the Bank shall not be liable for
                              any loss or damage either direct or any incidental, indirect, remote,
                              consequential, special loss or damage in this regard.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              TERMINATION/DISCONTINUANCE OF THE FACILITY
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User acknowledges and agrees that Alliance Partners of
                              the Bank may at their absolute discretion, suspend, terminate or
                              discontinue, wholly or partially, the Facility without giving any
                              notice to the Registered User and/or with/without reason. Bank shall
                              not be liable for any direct or indirect losses sustained by the
                              Visitor/Registered User arising out of such termination or
                              discontinuance.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Registered User shall remain responsible for any transactions
                              entered into by them and all obligations incurred by him until the
                              time of suspension/termination or discontinuance, as the case may be.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              DISCLAIMER
                              <br />
                              The Visitor/Registered User acknowledges and agrees that the
                              Visitor/Registered User has read the Disclaimer published on the
                              Website and hereby confirms such agreement to the terms stated
                              therein.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Website and the Facility do not constitute an offer or a
                              solicitation of an offer to sell, buy, provide, or procure any shares,
                              securities, or other instruments, products, or services to or from any
                              person in any jurisdiction.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank does not, in any way, solicit or encourage the Registered
                              User to use the Facility. Nothing provided on the Website should be
                              construed as advice of any nature and the Registered User is advised
                              to seek professional advice prior to taking any decision or action.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              NOTICES
                              <br />
                              The Visitor/Registered User should communicate with the Bank only via
                              the specified mode and in no other mode. Bank is not bound by the
                              communication received via any other mode. All communication whether
                              in writing or otherwise shall be valid only if the same is sent in the
                              format prescribed (if any) or approved by the Bank. The Bank may give
                              notice to the Visitor/Registered User by e-mail, letter, telephone, or
                              any other means, as Bank may deem fit, at the email
                              address/address/telephone or at any other contact that has been
                              provided by the Visitor/Registered User.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              APPLICABLE/GOVERNING LAW
                              <br />
                              The Website, T &amp; C, the Facility, all the transactions entered
                              into on or through the Website, as well as the relationship between
                              the Visitor/Registered User and Bank and obligations of the Bank,
                              shall be governed by laws of India and guidelines as may be issued by
                              RBI from time to time. Should there be any dispute and/or should any
                              court of law question the applicability of the governing law and
                              jurisdiction being India and by reason of which the Bank is not able
                              to initiate, continue with any dispute/proceedings/action, etc. in
                              connection with this agreement, then in such an event, the Bank shall
                              be at liberty to initiate appropriate proceedings/action under the
                              applicable law and jurisdiction, from where the Visitor/Registered
                              User carried out the transaction and/or under any other applicable law
                              and jurisdiction.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              This Facility is offered subject to the applicable laws of any other
                              country where the account of the Visitor/Registered User is maintained
                              including the country from which the instructions for remittance of
                              funds are given and it shall be the responsibility of the Registered
                              User (and not that of the Bank) to ensure that the said laws are
                              adhered to. In the event remittance instructions are given from a
                              country other than the country where the account of the
                              Visitor/Registered User is maintained, it shall be the responsibility
                              of the Registered User (and not that of the Bank) to ensure compliance
                              with applicable laws of both countries.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The Bank accepts no liability whatsoever, direct or indirect, for
                              non-compliance with the laws of any country. The mere fact that this
                              Facility can be accessed through the Internet or by phone or mobile in
                              a country other than India shall not be interpreted to imply that the
                              laws of that country govern these T &amp; C, and/or the access/use of
                              the Facility by the Visitor/Registered User.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              DISPUTE RESOLUTION
                              <br />
                              The Visitor/Registered User agrees that it will, at all times, make
                              all attempts to resolve all differences arising in respect of the
                              Website, T &amp; C, or any other agreement with the Bank by a
                              discussion with the Bank, failing which, by arbitration, provided that
                              the arbitration shall be by a sole arbitrator, nominated by the Bank.
                              In the event of death, refusal, neglect, inability, or incapability of
                              a person appointed to act as an arbitrator, the Bank shall appoint
                              another sole arbitrator. The arbitration shall be conducted in
                              accordance with the provisions of the Arbitration and Conciliation
                              Act, 1996, and shall be conducted in English. The place of arbitration
                              shall be Mumbai, India. The Visitor/Registered User waives any
                              objection to such proceedings on the grounds of the venue. Remedy of
                              arbitration shall be resorted to by the Visitor/Registered User or the
                              Bank unless the differences fall within the jurisdiction of the Debts
                              Recovery Tribunal established under the Recovery of Debts Due to Banks
                              and Financial Institutions Act, 1993, in which case the Tribunal will
                              have the jurisdiction over the matter.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Notwithstanding the aforesaid provisions, in the event of any breach
                              or threatened breach of the provisions of the T &amp; C or any other
                              agreement with the Bank by the Visitor/Registered User, the Bank shall
                              be entitled to (in addition to all other remedies) a court-ordered
                              injunction, restraining any such breach, without recourse to
                              arbitration. The Bank has the right to bring/file a claim/complaint
                              for injunctive relief in any competent court or judicial forum/local
                              authority having jurisdiction.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              In the event of any breach or threatened breach of the T &amp; C or
                              any other agreement with the Bank, by the Visitor/Registered User's
                              authorised representatives/employees or the respective agreements
                              between them and the Visitor/Registered User, the Visitor/Registered
                              User/shall cooperate with the Bank in such manner as may be required
                              to restrain such breach, including the pursuit of all legal remedies.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              MISCELLANEOUS
                              <br />
                              The Website, T &amp; C, the Visitor/Registered User's access to or use
                              of the Website or Facility are not intended to create an agency,
                              partnership, the joint-venture or employer-employee relationship
                              between the Visitor/Registered User on the one hand and the Bank, any
                              Alliance Partner, Correspondent Bank or Service Provider on the other
                              hand.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Visitor/Registered User agrees that the Bank may sub-contract or
                              employ or engage services of Correspondent Bank, Alliance Partner,
                              Service Provider, agents, consultants, contractors, content providers,
                              or representatives to carry out any of the provisions of the T &amp; C
                              and provision of the Facility. The Bank has not conducted any
                              investigation or due diligence in respect of and makes no warranty for
                              the Correspondent Bank, Alliance Partner, Service Provider, agents,
                              consultants, contractors, content providers, or the facilities
                              provided by them. The Bank shall not be responsible for any error,
                              negligent, or fraudulent acts or omissions of such persons or any acts
                              or omissions done outside the scope of their authority. Such persons
                              may have their own agreements, terms and conditions, which will govern
                              such services provided by them. The terms and warranties relating to
                              such services may vary. It shall be the duty of the Registered User to
                              obtain the full text of such terms and warranties from such persons.
                              Where any Facility is provided by Bank itself, it is expressly
                              mentioned on the Website.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Except as expressly provided in these T &amp; C, no exercise, or
                              failure to exercise, or delay in exercising any right, power, or
                              remedy vested in the Bank in respect of or arising out of these T
                              &amp; C shall constitute a waiver by the Bank of that or any other
                              right, power or remedy. If one or more of the provisions of T &amp; C
                              are unenforceable against the Visitor/Registered User, this will not
                              in any way affect the enforceability of the remainder of the T &amp;
                              C. The Bank at its sole discretion may decide to waive or relax any of
                              the provisions of the T &amp; C on a temporary basis or as a special
                              case and this will not affect the Bank's right to enforce that
                              provision strictly at any other time.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              In the event that any provision of these T &amp; C is held to be in
                              violation of any applicable law or if for any reason a court of
                              competent jurisdiction finds any provision of these T &amp; C, to be
                              unenforceable, that provision shall be enforced to the maximum extent
                              permissible so as to effect the intent of these T &amp; C, and the
                              remainder of these T &amp; C shall continue in full force and effect.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Disclaimer
                              <br />
                              This Website is owned and maintained by Kotak Mahindra Bank Limited
                              (referred to as "Bank" hereafter) for Visitor/Registered user
                              information, communication, education, and use. The Website may
                              contain links to other websites, having further linked websites,
                              operated by parties other than the Bank ("Linked Websites").
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The use of this Website is governed by the following terms and
                              conditions and other terms and conditions/policies as indicated on
                              this Website ("T &amp; C") and all applicable laws. By accessing and
                              using this Website Visitor/Registered user agrees to accept, without
                              limitation or qualification, all the T &amp; C. The Content (including
                              but not limited to information, material, news items, data, market
                              movements, etc.) of the Website including the T &amp; C is subject to
                              change at the sole discretion of the Bank, without prior notice.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank owns all the rights, titles, and interests including the
                              copyright in respect of all the Content including various logos,
                              trademarks, service marks, etc., unless indicated otherwise.
                              Visitor/Registered User may use/download the Content only for
                              noncommercial and personal use Visitor/Registered User shall not,
                              however, reproduce, distribute, redistribute, modify, transmit, reuse,
                              report, or use the Content for public or commercial purposes without
                              Bank's written permission. Visitor/Registered User shall not use the
                              Content for any illegal purpose.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Products and services offered on the Website are available only in
                              restricted geographical regions as indicated. This Website does not
                              offer any products or services to citizens of or in the jurisdictions
                              whose laws conflict with, differ from, or provide higher requirements
                              than those necessitated by, the laws of the Republic of India.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The development of the Website with respect to the Content and
                              software made available and products and services ("Products") offered
                              through it, is a continuous and ongoing process and Products are
                              provided on a "best effort basis". Bank makes all attempts to keep the
                              Products updated and accurate. Except where explicitly stated, Bank
                              makes no warranty or representation, including but not limited to any
                              warranties or representations as to the accuracy, reliability, or
                              completeness of the Products and/or fitness for a particular purpose,
                              and/or non-infringement with respect to the Website and/or Linked
                              Websites and/or the Products.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any Content on the Website must not be construed as investment advice,
                              and Visitor/Registered User should exercise due caution and/or seek
                              independent advice before entering into any investment or financial
                              obligation based on the Content.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              The contents displayed or the products/services offered on the Linked
                              Websites or any quality of the same are not endorsed, verified, or
                              monitored by Bank in any way. Bank makes no representation or
                              warranty, express or implied, of any kind whatsoever, pertaining to
                              the Linked Websites.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Though the Bank will take steps to prevent the introduction of viruses
                              and other such destructive materials on the Website, it does not
                              represent, warrant, or guarantee that the Website or the Content
                              downloaded from the Website or Linked Websites do not contain such
                              viruses or destructive materials. Bank is not liable for any damage or
                              harm attributable to such virus or destructive materials. The Bank
                              does not warrant that the Website or functions thereof will be
                              uninterrupted or free of any error or defect.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Bank shall not be liable to Visitor/Registered Users or any third
                              party (whether or not the access is authorised) for any cost, loss,
                              damage, or the like, incurred/suffered, directly or indirectly, due
                              to: Use of the Websites or Products in violation of the applicable
                              terms and conditions of such usage or the applicable laws or otherwise
                              failure to abide by such terms and conditions or laws.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any action based on the Content or any use or application of the same
                              or any error or omission relating to the transmission of the Content.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any of the following:{" "}
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              <table
                                width={560}
                                border={0}
                                align="center"
                                cellPadding={0}
                                cellSpacing={0}
                              >
                                <tbody>
                                  <tr>
                                    <td
                                      width={19}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      1.{" "}
                                    </td>
                                    <td
                                      width={541}
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      Bank's failure to act upon Visitors/Registered users’
                                      instructions,
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      2.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      Non-availability of any Internet services in the desired
                                      manner,
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      3.
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: '"Roboto", sans-serif',
                                        fontSize: 14,

                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: 5,
                                      }}
                                    >
                                      loss of any instruction in any communication channel or of any
                                      stored data/instructions; due to any reasons beyond the
                                      control of the Bank at the relevant point of time, including
                                      any problems and difficulties arising due to power and
                                      electricity failure, computer errors, programming errors,
                                      software or hardware errors, computer breakdown,
                                      non-availability of Internet connection, communication
                                      problems between the Bank's server and Visitors/Registered
                                      Users computer network, shutting down of the Bank's server,
                                      non-availability of links, corruption of the computer
                                      software, problems in the telecommunication network and any
                                      other technology related problems, natural
                                      calamities/disasters, legal restraints, industrial disputes or
                                      any other reason beyond the control of the Bank.
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any unauthorised transaction through this Website due to
                              Visitors/Registered Users’ fraudulent or negligent usage.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Any unauthorised/fraudulent/erroneous use of or hacking or intrusion
                              into the computer network of the Bank by any third party due to
                              Visitors/Registered Users’ negligent or fraudulent conduct, or if the
                              Bank has taken due and reasonable care to avoid such hacking
                              intrusion.
                            </td>
                          </tr>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 14,

                                color: "#323232",
                                textAlign: "left",
                                paddingBottom: 12,
                              }}
                            >
                              Visitors/Registered Users or any third party accessing the Website
                              irrevocably agrees to the exclusive jurisdiction of the courts at
                              Mumbai in relation to any matter connected or related to the use or
                              access of the Website and waives any objection to any proceedings on
                              the grounds of venue or on the grounds that the proceedings have been
                              brought in an inconvenient forum. The governing law in any legal
                              proceedings arising out of any product or service provided by the Bank
                              shall be the laws of the Republic of India.
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td align="center" valign="top" style={{ paddingTop: 20, paddingBottom: 20 }}>
                      <table
                        width={210}
                        border={0}
                        align="center"
                        cellPadding={0}
                        cellSpacing={0}
                        className="fixwidthdisclamier"
                      >
                        <tbody>
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 11,

                                color: "#323232",
                                textAlign: "right",
                                paddingRight: 8,
                                paddingTop: 1,
                                paddingBottom: 1,
                                borderRight: "1px solid #606060",
                              }}
                            >
                              <Link
                                to={"/disclaimer"}
                                style={{
                                  outline: "none",
                                  textDecoration: "underline",
                                  color: "#323232",
                                }}
                              >
                                Copyright &amp; Disclaimer
                              </Link>
                            </td>
                            <td
                              align="center"
                              valign="top"
                              style={{
                                fontFamily: '"Roboto", sans-serif',
                                fontSize: 11,

                                color: "#323232",
                                textAlign: "left",
                                paddingLeft: 8,
                                paddingTop: 1,
                                paddingBottom: 1,
                              }}
                            >
                              <Link
                                to={"/privacy-policy"}
                                style={{
                                  outline: "none",
                                  textDecoration: "underline",
                                  color: "#323232",
                                }}
                              >
                                Privacy Policy
                              </Link>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
