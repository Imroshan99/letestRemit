import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, Select, notification, Spin } from "antd";
import { AuthAPI } from "../../../apis/AuthAPI";
import { GuestAPI } from "../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import VerifyOtp from "../containers/VerifyOtp";
import Back_arrow from "../../../assets/images/click2remit/Back_arrow.svg";

import Main from "../Layouts/Main";
import Spinner from "../../../reusable/Spinner";
import { useNavigate } from "react-router-dom";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import { inputValidations } from "../../../services/validations/validations";

const { Option } = Select;
export default function ForgotUserID(props) {
  const ConfigReducer = useSelector((state) => state);
  const AuthReducer = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    phoneCodes: [],
    isModalVisible: false,
    verificationToken: "",
    verifiedToken: "",
    twofa: ConfigReducer.twofa,
    formData: {},
    _isShowOTPBOX: false,
    _isShowSuccessMessage: false,
    otpType: "FL",
  });

  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookForgotUserID = useHttp(AuthAPI.forgotUserID);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCoutryCodes();
  }, []);
  const getCoutryCodes = async () => {
    const payload = {
      requestType: "COUNTRYPHONECODE",
    };
    // props.AddRecipientFormsetLoader(true);
    setLoader(true);
    hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        let _recvCountryCode = data.responseData.filter(
          (item) => item.countryCode === AuthReducer.recvCountryCode,
        );

        setState({
          // phoneCodes: data.responseData,
          phoneCodes: [
            { countryPhoneCode: 1, countryName: "United States" },
            // { countryPhoneCode: 91, countryName: "India" },
          ],
          selectPhoneCodes: false,
          // mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
        });
        props.newForm1.setFieldsValue({
          mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
        });
        props.setLoader(false);
      }
    });
  };

  const onCreateLead = (value) => {
    form.setFields([
      { name: "mobilePhoneCode", errors: [] },
      { name: "mobileNo", errors: [] },
    ]);

    let forgotPasswordPayload = {
      requestType: "FORGOTLOGINID",
      emailId: "",
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      otpService: "EMAIL",
      otpType: "FL",
    };

    setLoader(true);
    hookForgotUserID.sendRequest(forgotPasswordPayload, (res) => {
      setLoader(false);
      if (res.status == "S") {
        notification.success({ message: "OTP has been sent to your registered email address." });
        setState({ verificationToken: res.verificationToken });

        if (state.twofa == "N") {
          setState({
            isModalVisible: true,
            formData: value,
          });
        } else {
          setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
        }
      } else {
        notification.error({ message: res.errorMessage });

        let errors = [];
        res.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  return (
    <Main sidebar={false}>
      <div className="container h-100 d-flex justify-content-center w-100">
        <Spinner spinning={loading}>
          {state._isShowOTPBOX ? (
            <>
              <VerifyOtp
                state={state}
                setState={setState}
                otpType={state.otpType}
                useFor="forgot_userId"
                appState={props.appState}
              />
            </>
          ) : (
            <>
              {state._isShowSuccessMessage == false ? (
                <Form form={form} initialValues={{ verifyType: "O" }} onFinish={onCreateLead}>
                  <div className="CR-otp-form-parent" style={{ minHeight: "0px" }}>
                    <div className="CR-otp-form-child">
                      <ul className="row d-flex flex-column align-items-center">
                        <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                          <h4 className="text-black text-center">Forgot Your User ID?</h4>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12">
                          <p className="text-center">
                            A 6 digit OTP will be sent to your registered email id.
                          </p>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12">
                          <CustomInput
                            showLabel={false}
                            name="mobilePhoneCode"
                            label="Select Phone Code"
                            required
                          >
                            <FloatInput
                              type="select"
                              placeholder="Select Phone Code"
                              label="Phone Code"
                              name="mobilePhoneCode"
                              showSearch
                            >
                              {state.phoneCodes.map((phoneCode, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={phoneCode.countryPhoneCode}
                                  >{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                                );
                              })}
                            </FloatInput>
                          </CustomInput>

                          {/* <Form.Item
                            className="form-item"
                            name="mobilePhoneCode"
                            rules={[
                              {
                                required: true,
                                message: "Please select your Country Code.",
                              },
                            ]}
                          >
                            <Select
                              size="large"
                              className="w-100"
                              placeholder="Select Country Code"
                            >
                              {state.phoneCodes.map((phoneCode, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={phoneCode.countryPhoneCode}
                                  >{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                                );
                              })}
                            </Select>
                          </Form.Item> */}
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12">
                          <CustomInput
                            showLabel={false}
                            name="mobileNo"
                            label="Mobile Number"
                            validationRules={[...inputValidations.mobileNumber()]}
                            required
                          >
                            <FloatInput type="text" placeholder="Mobile Number" />
                          </CustomInput>
                          {/* <Form.Item
                            className="form-item"
                            name="mobileNo"
                            rules={[
                              {
                                required: true,
                                message: "Please input your Mobile Number.",
                              },
                              {
                                min: 10,
                                max: 10,
                                message: "Mobile number must be 10 digit.",
                              },
                              // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                            ]}
                          >
                            <Input size="large" placeholder="123456789" maxLength={10} />
                          </Form.Item> */}
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12">
                          <Form.Item name="verifyType" hidden={true}>
                            <Input type={"hidden"} />
                          </Form.Item>
                        </li>
                      </ul>
                    </div>
                    <div className="bottom_panel-otp-box p-0">
                      <div className="d-flex justify-content-between align-items-center w-100">
                        <div
                          className="Back_arrow d-flex align-items-center"
                          onClick={() => {
                            navigate("/signin");
                          }}
                        >
                          <img src={Back_arrow} alt="backArrow" /> Back
                        </div>
                        <button
                          style={{ width: "0px" }}
                          className="btn btn-primary CR-primary-btn CR-primary-btn-media-query"
                        >
                          {/* {state.twofa == "Y" ? "Verify With OTP" : "Verify Without OTP"} */}
                          Verify With OTP
                        </button>
                      </div>
                    </div>
                  </div>
                </Form>
              ) : (
                <div className="CR-otp-form-parent" style={{ minHeight: "0px" }}>
                  <div className="CR-otp-form-child">
                    <ul className="row d-flex flex-column align-items-center">
                      <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                        <h4>Done ! Your User ID has been sent to your registered email ID</h4>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </>
          )}
        </Spinner>
      </div>
    </Main>
  );
}
