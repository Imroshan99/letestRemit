import React, { useEffect, useReducer, useState } from "react";
import logorefresh from "../../../../assets/images/svg/refreshCaptcha.svg";
import { Form, Input, Row, Col, notification } from "antd";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { passwordValidate } from "../../../../services/validations/group";
import { passwordStrength } from "../../../../services/utility/Helper";
import Spinner from "../../../../reusable/Spinner";
import EditProfileOTPBox from "../../../../containers/EditProfileOTPBox";
import CustomInput from "../../../../reusable/CustomInput";

export default function ChangePassword(props) {
  const [loader, setLoader] = useState(0);
  const [captchaID, setCaptchaID] = useState();
  const [captchaImg, setCaptchaImg] = useState();
  const [strengthBadge, setStrengthBadge] = useState("None");
  const [strengthBadgeConfPass, setstrengthBadgeConfPass] = useState("None");
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    twofa: AuthReducer.twofa,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
    newPassword: "",
    confNewPassword: "",
    mobileNo: "",
    mobilePhoneCode: "",
    emailId: "",
    verificationToken: "",
    OTPInputBox: false,
    oldPassword: "",
  });

  const hookChangePassword = useHttp(ProfileAPI.changePassword);
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCaptcha();
    getProfile();
  }, []);

  const getProfile = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getCaptcha = () => {
    let payload = {
      requestType: "GETCAPTCHA",
    };
    setLoader((prevState) => prevState + 1);
    hookgetCaptcha.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        setCaptchaID(data.id);
        setCaptchaImg(data.captchaImage);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const changePassword = (verifiedToken) => {
    let changePasswordPayload = {
      requestType: "CHANGEPASSWORD",
      userId: AuthReducer.userID,
      oldPassword: state.oldPassword,
      newPassword: state.newPassword,
      twofa: "Y",
      verifiedToken: verifiedToken,
    };
    setLoader((prevState) => prevState + 1);
    hookChangePassword.sendRequest(changePasswordPayload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = "/signin";
          }
        });
      } else {
        setState({ OTPInputBox: false });
        getCaptcha();
        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };
  const onFinish = (value) => {
    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
    };
    setLoader((prevState) => prevState + 1);
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      setLoader((prevState) => prevState - 1);

      if (data.status == "S") {
        const OTPData = {
          requestType: "SENDOTP",
          mobilePhoneCode: state.mobilePhoneCode,
          mobileNo: state.mobileNo,
          emailId: state.emailId,
          otpType: "CP",
          senderName: "",
          userId: state.userID,
          otpOption: "SM",
        };
        setLoader((prevState) => prevState + 1);
        hookSendOTP.sendRequest(OTPData, function (data) {
          setLoader((prevState) => prevState - 1);
          if (data.status == "S") {
            notification.success({ message: data.message });
            setState({ verificationToken: data.verificationToken, OTPInputBox: true, oldPassword: value.oldPassword, newPassword: value.newPassword });
          } else {
            notification.error({ message: data.errorMessage });
            getCaptcha();
          }
        });
      } else {
        form.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
      }
    });
  };
  const passwordStrenthHandler = (e) => {
    setStrengthBadge(e.target.value == "" ? "None" : passwordStrength(e.target.value));
  };

  const confPasswordHandler = (e) => {
    setstrengthBadgeConfPass(e.target.value == "" ? "None" : passwordStrength(e.target.value));
  };

  return (
    <div>
      <Spinner spinning={loader === 0 ? false : true}>
        <div className="template2__main">
          <div className="container change_password__page">
            {!state.showConfirmBankAccountDetails && (
              <Form form={form} onFinish={onFinish}>
                <div className="ChangePassword">
                  <div className="row ">
                    <div className="col-md-5">
                      <CustomInput className="form-item" name="oldPassword" label="Current Password" required>
                        <Input.Password disabled={state.OTPInputBox} size="large" />
                      </CustomInput>
                    </div>
                    <div className="col-md-12 ">
                      <div className="b_line"></div>
                    </div>
                  </div>

                  <div className="row mt-5">
                    <div className="col-md-5">
                      <CustomInput className="form-item" name="newPassword" label="Choose a New Password" validationRules={[...passwordValidate("XR")]} required>
                        <div className="d-flex ">
                          <Input.Password
                            visibilityToggle={false}
                            onChange={passwordStrenthHandler}
                            disabled={state.OTPInputBox}
                            size="large"
                            maxLength={20}
                            addonAfter={
                              <div className="text-primary">
                                Strength: <span className="text-info-dark">{strengthBadge}</span>
                              </div>
                            }
                          />
                        </div>
                      </CustomInput>
                      <CustomInput
                        className="form-item"
                        name="ConfirmNewPassword"
                        label="Confirm New Password"
                        validationRules={[
                          ...passwordValidate("XR"),
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (!value || getFieldValue("newPassword") === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject("Confirm password does not match with new password");
                            },
                          }),
                        ]}
                        required
                      >
                        <div className="d-flex">
                          <Input.Password
                            visibilityToggle={false}
                            disabled={state.OTPInputBox}
                            onChange={confPasswordHandler}
                            size="large"
                            maxLength={20}
                            addonAfter={
                              <div className="text-primary">
                                Strength: <span className="text-info-dark">{strengthBadgeConfPass}</span>
                              </div>
                            }
                          />
                        </div>
                      </CustomInput>
                      <p className="text-info m-0">
                        <small className="fs-12 fw-700">Password must contain at least one Uppercase Letter, at least one Lowercase letter and at least one special symbol</small>
                      </p>
                    </div>
                    <div className="col-md-2 text-center d-none d-md-block">
                      <span className="_v_line_secondary mt-5" style={{ height: "100px" }}></span>
                    </div>
                    {state.OTPInputBox ? (
                      <div className="col-md-5">
                        <EditProfileOTPBox state={state} setState={setState} otpType="UL" useFor="signup" appState={props.appState} setCurrent={props.setCurrent} setLoader={setLoader} changePassword={changePassword} />
                      </div>
                    ) : (
                      <div className="col-md-5">
                        <label className="form-label">Word Verification</label>
                        <div className="w-100 d-flex mb-3">
                          <div className="me-3">
                            <img src={`data:image/jpeg;base64,${captchaImg}`} alt="captcha" />
                          </div>
                          <div className="d-flex align-items-center my-3" style={{ cursor: "pointer" }} onClick={getCaptcha}>
                            <img src={logorefresh} alt="refresh" className="me-2" />
                            <span className="fs-12 fw-600">Refresh Code</span>
                          </div>
                        </div>
                        <CustomInput className="form-item" name="captcha" required placeholder="Enter the text shown in the Image" showLabel={false} label="Captcha"/>
                      </div>
                    )}
                  </div>

                  {!state.OTPInputBox && (
                    <div className="d-flex justify-content-end">
                      <button className="mt-5 btn btn-sm btn-light text-primary" type="submit">
                        Get OTP
                      </button>
                    </div>
                  )}
                </div>
              </Form>
            )}
          </div>
        </div>
      </Spinner>
    </div>
  );
}
