import React from "react";
import { useSelector } from "react-redux";
import KycFlowOne from "./KycFlowOne/Kyc";
import KycFlowTwo from "./KycFlowTwo/Kyc";
import { Modal } from "antd";

const KycModal = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const groupConfig = useSelector((state) => state.user);
  const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
  return (
    <Modal centered visible={props.visible} onCancel={() => props.setVisible(false)} forceRender={true} footer={null} width={500}>
      {templateFlow === "FLOW1" && <KycFlowOne appState={props.appState} manageAuth={props.manageAuth} />}
      {templateFlow === "FLOW2" && <KycFlowTwo appState={props.appState} manageAuth={props.manageAuth} />}
    </Modal>
  );
};

export default KycModal;
