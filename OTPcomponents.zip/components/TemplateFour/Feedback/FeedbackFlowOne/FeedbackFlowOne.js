import React, { useEffect, useState } from "react";
import { notification, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import { Form, Input } from "antd";

import firstUnfillEmoji from "../../../../assets/images/emojis/Unfill_Emoji/1.svg";
import secoundUnfillEmoji from "../../../../assets/images/emojis/Unfill_Emoji/2.svg";
import thirdUnfillEmoji from "../../../../assets/images/emojis/Unfill_Emoji/3.svg";
import fourthUnfillEmoji from "../../../../assets/images/emojis/Unfill_Emoji/4.svg";
import fiveUnfillEmoji from "../../../../assets/images/emojis/Unfill_Emoji/5.svg";

import firstFill from "../../../../assets/images/emojis/Fill_Emoji/1-fill.svg";
import secoundFill from "../../../../assets/images/emojis/Fill_Emoji/2-fill.svg";
import thirdFill from "../../../../assets/images/emojis/Fill_Emoji/3-fill.svg";
import forthfill from "../../../../assets/images/emojis/Fill_Emoji/4-fill.svg";
import fiveFill from "../../../../assets/images/emojis/Fill_Emoji/5-fill.svg";

import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import Spinner from "../../../../reusable/Spinner";
import CustomInput from "../../../../reusable/CustomInput";
const { TextArea } = Input;
const { Option } = Select;

export default function FeedbackFlowOne(props) {
  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();
  const [form1] = Form.useForm();

  const [rating, setRating] = useState("0");
  const [validation, setValidation] = useState(false);
  const [loader, setLoader] = useState(false);
  const [state, setState] = useState(0);
  const [phoneCodes, setPhoneCodes] = useState([]);

  const hookFeedbackPostLogin = useHttp(GuestAPI.contactUsPostLogin);
  const hookFeedbackPreLogin = useHttp(GuestAPI.contactUsPreLogin);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);

  useEffect(() => {
    getCountryPhoneCode();
  }, []);
  const getCountryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setLoader(true);
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ];
        setPhoneCodes(phoneCodeStatic);
        // setState({ phoneCodes: phoneCodeStatic });
      }
    });
  };
  const submitFeedback = (value) => {
    setLoader(true);
    if (state === 0) {
      setLoader(false);
      setValidation(true);
    } else {
      setValidation(false);
      let payload = {
        requestType: "POSTCONTACTUS",
        category: value.category,
        comments: value.comments.trim(),
        userId: AuthReducer.userID,
        pageFrom: "POST",
        identifier: "FB",
        rating: rating,
      };
      hookFeedbackPostLogin.sendRequest(payload, function (data) {
        if (data.status === "S") {
          setLoader(false);
          Swal.fire({
            title: "Success",
            text: data.message,
            icon: "success",
            confirmButtonColor: "#2dbe60",
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/new-transaction");
            }
          });
        } else {
          setLoader(false);
          notification.error({ message: data.errorMessage });
        }
      });
    }
  };
  const submitFeedbackPreLogin = (value) => {
    if (state === 0) {
      setValidation(true);
    } else {
      let payload = {
        requestType: "PRECONTACTUS",
        category: value.category,
        fullName: value.fullName.trim(),
        mobilePhoneCode: value.mobilePhoneCode,
        mobileNo: value.mobileNo,
        emailId: value.emailId,
        comments: value.comments.trim(),
        rating: rating,
        pageFrom: "PRE",
        identifier: "FB",
      };
      setLoader(true);
      hookFeedbackPreLogin.sendRequest(payload, function (data) {
        setLoader(false);
        if (data.status === "S") {
          Swal.fire({
            title: "Success",
            text: data.message,
            icon: "success",
            confirmButtonColor: "#2dbe60",
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/");
            }
          });
        } else {
          notification.error({ message: data.errorMessage });
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form1.setFields(errors);
        }
      });
    }
  };
  return (
    <React.Fragment>
      <Spinner spinning={loader}>
        <div className="template2__main">
          <div className="sendmoney__page preloginform">
            <div className="container">
              <div>
                {props.appState.isLoggedIn ? (
                  <Form form={form} onFinish={submitFeedback}>
                    <Row>
                      <Col>
                      <CustomInput label="Select category" name={"category"} type="select" placeholder="Select" size="large" required >
                          <Option value="Money Transfer">Money Transfer</Option>
                              <Option value="Exchange Rate">Exchange Rate</Option>
                              <Option value="Service Fee">Service Fee</Option>
                              <Option value="Payment Gateway">Payment Gateway</Option>
                              <Option value="Portal Experien">Portal Experience</Option>
                              <Option value="Others">Others</Option>
                          </CustomInput>

                          <CustomInput label="Describe your Feedback" name={"comments"}  required>
                          <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                          </CustomInput>
                      </Col>
                      <Col>
                        <label className="step-label">How Likely would recommend us tou your friend</label>
                        <div className="d-flex gap-3">
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setState(1);
                              setRating("1");
                              setValidation(false);
                            }}
                            src={state === 1 ? firstFill : firstUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setState(2);
                              setRating("2");
                              setValidation(false);
                            }}
                            src={state === 2 ? secoundFill : secoundUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setState(3);
                              setRating("3");
                              setValidation(false);
                            }}
                            src={state === 3 ? thirdFill : thirdUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setState(4);
                              setRating("4");
                              setValidation(false);
                            }}
                            src={state === 4 ? forthfill : fourthUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setState(5);
                              setRating("5");
                              setValidation(false);
                            }}
                            src={state === 5 ? fiveFill : fiveUnfillEmoji}
                            alt="Emoji"
                          />
                        </div>
                        {validation && (
                          <div>
                            <span style={{ color: "#ff4d4f" }}>Please give us rating</span>
                          </div>
                        )}
                        <div style={{ width: "15.31rem", marginTop: "5px" }} className="d-flex justify-content-between">
                          <span className="rating_below_text">Very Unlikely</span>
                          <span className="rating_below_text">Very Likely</span>
                        </div>
                      </Col>
                    </Row>

                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                ) : (
                  <Form form1={form1} onFinish={submitFeedbackPreLogin}>
                    <Row>
                      <Col>
                        <Row>
                          <CustomInput
                            name="fullName"
                            label="Your Name"
                            className="form-item"
                            size="large"
                            placeholder="Enter your Name"
                            validationRules={[
                              {
                                pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
                                message: "Please enter valid name.",
                              },
                              {
                                pattern: /^([^0-9]*)$/,
                                message: "Number not allow in full name",
                              },
                            ]}
                            required
                          />
                        </Row>
                        <Row>
                          <CustomInput label="Email address" className="form-item" name="emailId" type="email" size="large" placeholder="Enter your email address" required />
                        </Row>
                        <Row>
                          <label className="step-label   mb-1">Mobile Number</label>
                          <div className="d-flex group_input">
                            <div className="w-25 ">
                             
                              <CustomInput type="select" className="form-item" name="mobilePhoneCode" showLabel={false} required label="Country Code">
                                {phoneCodes.map((phoneCode, i) => {
                                  return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                                })}
                              </CustomInput>
                            </div>
                            <div className="w-75">
                             
                              <CustomInput
                              className="form-item"
                              name="mobileNo"
                              showLabel={false}
                              label="Mobile Number"
                              validationRules={[
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only numbers allowed",
                                },
                              ]}
                              min={10}
                              max={10}
                              placeholder="Enter your mobile number"
                              size="large"
                              required
                            />
                            </div>
                          </div>
                        </Row>
                      </Col>
                      <Col>
                        <Row>
                          <CustomInput label="Select category" name={"category"} type="select" placeholder="Select" size="large" required >
                          <Option value="Money Transfer">Money Transfer</Option>
                              <Option value="Exchange Rate">Exchange Rate</Option>
                              <Option value="Service Fee">Service Fee</Option>
                              <Option value="Payment Gateway">Payment Gateway</Option>
                              <Option value="Portal Experien">Portal Experience</Option>
                              <Option value="Others">Others</Option>
                          </CustomInput>
                        </Row>
                        <Row>
                          <CustomInput label="Describe your Feedback" name={"comments"}  required>
                          <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                          </CustomInput>
                        </Row>
                        <Row>
                          <label className="step-label">How Likely would recommend us tou your friend</label>
                          <div className="d-flex gap-3">
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setState(1);
                                setRating("1");
                                setValidation(false);
                              }}
                              src={state === 1 ? firstFill : firstUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setState(2);
                                setRating("2");
                                setValidation(false);
                              }}
                              src={state === 2 ? secoundFill : secoundUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setState(3);
                                setRating("3");
                                setValidation(false);
                              }}
                              src={state === 3 ? thirdFill : thirdUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setState(4);
                                setRating("4");
                                setValidation(false);
                              }}
                              src={state === 4 ? forthfill : fourthUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setState(5);
                                setRating("5");
                                setValidation(false);
                              }}
                              src={state === 5 ? fiveFill : fiveUnfillEmoji}
                              alt="Emoji"
                            />
                          </div>
                          {validation && (
                            <div>
                              <span style={{ color: "#ff4d4f" }}>Please give us rating</span>
                            </div>
                          )}
                          <div style={{ width: "15.31rem", marginTop: "5px" }} className="d-flex justify-content-between">
                            <span className="rating_below_text">Very Unlikely</span>
                            <span className="rating_below_text">Very Likely</span>
                          </div>
                        </Row>
                      </Col>
                    </Row>

                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                )}
              </div>
            </div>
          </div>
        </div>
      </Spinner>
    </React.Fragment>
  );
}
