import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import FeedbackFlowOne from "./FeedbackFlowOne/FeedbackFlowOne";
const Feedback = (props) => {
    const AuthReducer = useSelector((state) => state.user);
    const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
    const templateFlow = AuthReducer.groupIdSettings?.feedback?.flow;
    return (
      <>
        <Dashboard pageTitle="Feedback">
          {templateFlow === "FLOW1" && (
            <FeedbackFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
           {templateFlow === "FLOW2" && (
            <FeedbackFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
          {/* {templateFlow === "FLOW2" && (
            <TransactionAction2
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
        </Dashboard>
      </>
    );
  };
  
  export default Feedback;
  