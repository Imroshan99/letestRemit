import { useSelector } from "react-redux";
import AuthTemplate from "../Layouts/Auth";
import SignUpFlowOne from "./SignUpFlowOne/SignUp";
import SignUpFlowTwo from "./SignUpFlowTwo/SignUp";
import SingleSignUpForm from "./SingleSignUpForm/SingleSignUpForm";

const SignUp = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow = AuthReducer.groupIdSettings?.signUpForm?.flow;
  return (
    <>
      <AuthTemplate>
        {templateFlow === "FLOW1" && (
          <SignUpFlowOne
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
        {templateFlow === "FLOW2" && (
          <SignUpFlowTwo
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
        {templateFlow === "FLOW3" && (
          <SingleSignUpForm
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
      </AuthTemplate>
    </>
  );
};

export default SignUp;
