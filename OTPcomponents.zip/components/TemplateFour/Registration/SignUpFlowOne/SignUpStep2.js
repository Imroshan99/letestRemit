import React, { useEffect, useState } from "react";
import { Form, Input,Spin, Select, notification } from "antd";
import { AuthAPI } from "../../../../apis/AuthAPI";
import InputOTPBox from "../../../../containers/InputOTPBox";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;

export default function SignUpStep2(props) {
  const [form] = Form.useForm();
  let state = props.state;
  const [btn, setBtn] = useState(false);
  const [getotpBtn, setGetOtpBtn] = useState(true);
  const [mobileDisable, SetMobileDisable] = useState(false);
  const [spinner, setSpinner] = useState(false);
  const [recCountryList, setRecCountryList] = useState([]);

  const hookSaveLeads = useHttp(AuthAPI.saveLeads);
  const hookCheckDedupe = useHttp(AuthAPI.checkDedupe);
  const hookRecvCountryList = useHttp(GuestAPI.receiverCountryList);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    recvCountryList();
  }, []);

  const recvCountryList = async () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    hookRecvCountryList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setRecCountryList(data.responseData);
      }
    });
  };

  const onCreateLead = (value) => {
    setSpinner(true);
    let sendCountry = "";
    state.sendCountryList.find((i) => {
      if (i.countryName == value.country) {
        sendCountry = i.sendCountry;
        props.SetSendCountryState(sendCountry);
      }
    });

    let trimName = props.stepsData.name.trim();
    let nameSplit = trimName?.split(" ");
    let firstName = "";
    let lastName = "";
    let middleName = "";
    if (nameSplit.length == 2) {
      firstName = nameSplit[0];
      middleName = "";
      lastName = nameSplit[1];
    } else if (nameSplit.length == 3) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = nameSplit[2];
    } else if (nameSplit.length >= 4) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = `${nameSplit[nameSplit.length - 2]} ${
        nameSplit[nameSplit.length - 1]
      }`;
    }
    form.setFields([
      { name: "country", errors: [] },
      { name: "firstName", errors: [] },
      { name: "middleName", errors: [] },
      { name: "lastName", errors: [] },
      { name: "mobilePhoneCode", errors: [] },
      { name: "mobileNo", errors: [] },
      { name: "dob", errors: [] },
      { name: "emailId", errors: [] },
    ]);

    // var marketingCommunication = "";
    // props.stepsData.marketingCommunicationMedia.forEach((data) => {
    //   marketingCommunication = marketingCommunication + "~" + data;
    // });

    var marketingCommunication =
      "~" + props.stepsData.marketingCommunicationMedia + "~";
    if (props.stepsData.marketingCommunicationMedia === "Other") {
      marketingCommunication =
        "~" + props.stepsData.marketingCommunicationMediaOther + "~";
    }

    let leadData = {
      requestType: "LEAD",
      firstName: firstName,
      middleName: middleName,
      lastName: lastName,
      gender: props.stepsData.gender,
      loginId: props.stepsData.email,
      emailId: props.stepsData.email,
      sendCountry: value.country,
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      dob: props.state.dob,
      lpID: "",
      pageReferer: "savsa",
      custType: "INDIVITUAL",
      periodicUpdate: "N", //if yes then marketingCommunication pass
      marketingCommunication: marketingCommunication,
      otpFlag: state.twofa,
    };

    hookSaveLeads.sendRequest(leadData, function (data) {
      value.leadId = data.leadId;
      value.marketingCommunication = marketingCommunication;

      if (data.status == "S") {
        notification.success({
          // message: data.message,
          message: "OTP sent to registered mail ID",
        });
        props.setState({ verificationToken: data.verificationToken });

        if (state.twofa == "N") {
          props.setState({
            _isShowSetPassword: true,
            isModalVisible: true,
            formData: value,
          });
        } else {
          props.setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
          SetMobileDisable(true);
          setSpinner(false);
          setGetOtpBtn(false);
        }
      } else {
        setSpinner(false);
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const checkDedupe = () => {
    let trimName = props.stepsData.name.trim();
    let nameSplit = trimName?.split(" ");
    let firstName = "";
    let lastName = "";
    let middleName = "";
    if (nameSplit.length == 2) {
      firstName = nameSplit[0];
      middleName = "";
      lastName = nameSplit[1];
    } else if (nameSplit.length == 3) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = nameSplit[2];
    } else if (nameSplit.length >= 4) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = `${nameSplit[nameSplit.length - 2]} ${
        nameSplit[nameSplit.length - 1]
      }`;
    }
    let payload = {
      requestType: "DEDUPECHECK",
      firstName: firstName,
      lastName: lastName,
      emailId: props.stepsData.email,
      mobilePhoneCode: state.formData.mobilePhoneCode,
      mobileNo: state.formData.mobileNo,
      dob: state.dob,
      countryCode: "GB",
    };
    hookCheckDedupe.sendRequest(payload, function (data) {
      props.setState({ _isShowSetPassword: true });
    });
  };

  const handleRecvCountry = (value) => {
    const arcountryPhoneCode = state.phoneCodes.filter(
      (v, i) => v.countryCode === value
    );
    form.setFieldsValue({
      mobilePhoneCode: arcountryPhoneCode[0].countryPhoneCode,
    });
  };

  return (
    <Form
      form={form}
      autoComplete="none"
      onFinish={onCreateLead}
      initialValues={{
        country: "GB",
        mobilePhoneCode: "44",
        recvCountry: "IN",
      }}
    >
      <label className="step-label  mb-1">Select Your Country</label>
      <CustomInput label="Select your country" showLabel={false} name="country" required type="select" onChange={handleRecvCountry}>
        {state.sendCountryList.map((clist, i) => {
          return <Option key={i} value={clist.sendCountry}>{`${clist.countryName}`}</Option>;
        })}
      </CustomInput>
       

      <label className="step-label  mb-1">Select Receive Country</label>

      <CustomInput className="form-item" name="recvCountry" type="select" label="Select Receive Country" showLabel={false} disabled>
        {recCountryList.map((v, i) => {
          return (
            <Option key={i} value={v.recvCountry}>
              {v.countryName}
            </Option>
          );
        })}
      </CustomInput>
       

      <label className="step-label   mb-1">Mobile Number</label>
      <div className="d-flex gap-1">
        <div className="w-25 ">
          <CustomInput className="form-item" name="mobilePhoneCode" type="select" label="Mobile Number" showLabel={false} required>
            {state.phoneCodes.map((phoneCode, i) => {
              return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
            })}
          </CustomInput>
          
          
        </div>
        <div className="w-75">
          <CustomInput
            name="mobileNo"
            min={10}
            max={10}
            label="Mobile Number"
            showLabel={false}
            maxLength={10}
            disabled={mobileDisable}
            onChange={(e) => {
              e.target.value.length === 10 ? setBtn(true) : setBtn(false);
            }}
            validationRules={[
              {
                pattern: /^[0-9\b]+$/,
                message: "Only numbers allowed",
              },
            ]}
          />
           
        </div>
      </div>
      <Spin spinning={spinner}>
        {getotpBtn && (
          <button className={`btn btn-primary text-white my-1 w-100`} disabled={!btn || spinner} htmlType="submit">
            {state.twofa == "Y" ? "GET OTP ON EMAIL" : "Verify Without OTP"}
          </button>
        )}
      </Spin>
      {state._isShowOTPBOX ? (
        ""
      ) : (
        <button className={`btn btn-primary text-white my-1 w-100`} disabled={true}>
          Next
        </button>
      )}

      <>{state._isShowOTPBOX && <InputOTPBox state={state} setState={props.setState} checkDedupe={checkDedupe} otpType="UL" useFor="signup" appState={props.appState} setCurrent={props.setCurrent} />}</>
    </Form>
  );
}
