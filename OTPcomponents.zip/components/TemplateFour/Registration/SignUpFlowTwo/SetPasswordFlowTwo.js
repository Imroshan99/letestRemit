import React, { useState, useReducer, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin } from "antd";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { AuthAPI } from "../../../../apis/AuthAPI";

function SetPasswordFlowTwo(props) {
  const ConfigReducer = useSelector((state) => state.user);
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
  });

  const hookSignUp = useHttp(AuthAPI.signUp);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const saveSignUpData = (value) => {
    form.setFields([{ name: "password", errors: [] }]);
    const signUPData = {
      requestType: "SIGNUP",
      sendCountry: props.state.formData.country,
      firstName: props.state.formData.firstName,
      middleName: props.state.formData.middleName ? props.state.formData.middleName : "",
      lastName: props.state.formData.lastName,
      loginId: props.state.formData.emailId,
      emailId: props.state.formData.emailId,
      password: value.password,
      passwordType: "PASSWORD",
      dob: props.state.dob,
      leadId: props.state.formData.leadId,
      mobilePhoneCode: props.state.formData.mobilePhoneCode,
      mobileNo: props.state.formData.mobileNo,
      recvCountry: ConfigReducer.recvCountryCode,
      gender: props.state.formData.gender,
      altMobilePhoneCode: "",
      altMobileNo: "",
      marketingRef: "website~google",
      address1: "",
      address2: "",
      state: "",
      city: "",
      zip: "",
      euroCountry: "",
      pageReferer: "",
      lpId: "",
      custType: "INDIVIDUAL",
      sameBankCust: "Y",
      bankCustID: "",
      accountNo: "",
      nationality: "",
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      tnc: "",
      periodicUpdate: "N", //if yes then marketingCommunication pass
      marketingCommunication: props.state.formData.marketingCommunication,
      twofa: state.twofa,
      verifiedToken: props.state.verifiedToken,
    };

    setLoader(true);
    hookSignUp.sendRequest(signUPData, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        navigate("/signin");
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          if (error.field != "password") {
            notification.error({ message: error.error });
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  return (
    <div className="bg-light text-dark shadow-md rounded  pt-sm-4">
      <h3 className="fw-400 text-center mb-4">Set a password</h3>
      <hr className="mx-n5" />
      <div className="rounded p-3 pt-sm-4 pb-sm-5 px-sm-5">
        {/* <p className="lead text-center">We are glad to see you again!</p> */}
        <Form form={form} onFinish={saveSignUpData}>
          <div className="mb-3">
            <label htmlFor="exampleFormControlInput1" className="form-label">
              Password
            </label>
            <Form.Item
              className="form-item"
              name="password"
              rules={[
                { required: true, message: "Please input your Password." },
                {
                  min: 3,
                  max: 35,
                  message: "Password should be between 3 and 35 characters long.",
                },
              ]}
            >
              <Input.Password
                size="large"
                placeholder="Enter your Password"
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
              />
            </Form.Item>
          </div>
          <div className="mb-3">
            <label htmlFor="exampleFormControlInput1" className="form-label">
              Confirm Password
            </label>
            <Form.Item
              className="form-item"
              name="confirmPassword"
              rules={[
                {
                  required: true,
                  message: "Please input your Confirm Password.",
                },
                ({ getFieldValue }) => ({
                  validator(rule, value) {
                    if (!value || getFieldValue("password") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject("The two password that you entered do not match!");
                  },
                }),
              ]}
            >
              <Input.Password
                size="large"
                placeholder="Enter your Confirm Password"
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
              />
            </Form.Item>
          </div>
          <div className="my-4"></div>
          <Spin spinning={loading} delay={500}>
            <div className="d-grid g-2">
              <button className="btn btn-primary text-white my-1" type="submit">
                Sign Up
              </button>
            </div>
          </Spin>
          <div className="d-grid g-2">
            <button
              className="btn btn btn-secondary my-1"
              type="button"
              onClick={() =>
                props.setState({
                  _isShowOTPBOX: false,
                  _isShowSetPassword: false,
                })
              }
            >
              Back
            </button>
          </div>
        </Form>
      </div>
    </div>
  );
}

export default SetPasswordFlowTwo;
