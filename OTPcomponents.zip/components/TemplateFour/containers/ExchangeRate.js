import React, { useState, useEffect, useReducer, Fragment } from 'react'
import { Table } from 'antd';
import { GuestAPI } from '../apis/GuestAPI';
import Spinner from '../../../reusable/Spinner';

function ExchangeRate() {

    const [loading, setLoader] = useState(false);
    const [state, setState] = useReducer(
        (state, newState) => ({ ...state, ...newState }),
        {
            exRateList: [],
            pubDate: "",
            pubDateTZ: "",
            rate: "",
            recvCurrency: "",
            sendCurrency: ""
        }
    );

    useEffect(() => {
        setLoader(true)
        GuestAPI.getExchangeRates()
            .then(res => {
                if (res.data.message == "success") {
                    let resData = [];
                    res.data.details.forEach((detail, i) => {
                        let data = {
                            key: i,
                            currency: `${detail.rangeFrom} to ${detail.rangeTo} ${res.data.sendCurrency}`,
                            exchangeRate: `${detail.exchangerate} ${res.data.recvCurrency}`
                        }

                        resData.push(data);
                    });

                    setState({
                        exRateList: resData,
                        pubDate: res.data.pubDate,
                        pubDateTZ: res.data.pubDateTZ,
                        rate: res.data.rate,
                        recvCurrency: res.data.recvCurrency,
                        sendCurrency: res.data.sendCurrency
                    })
                }
                setLoader(false)
            }).catch(error => setLoader(false))
    }, [])

    return (
        <div>
            <Spinner spinning={loading} delay={100}>
                {
                    state.enteredAmount != '' &&
                    <Fragment>
                        <Table
                            columns={[
                                {
                                    title: "Currency",
                                    dataIndex: "currency"
                                },
                                {
                                    title: "Exchange Rate",
                                    dataIndex: "exchangeRate"
                                }
                            ]}
                            dataSource={state.exRateList}
                            pagination={false}
                        />
                        <p>Confirmed Exchange Rates offered on {state.pubDate}</p>
                    </Fragment>
                }

            </Spinner>
        </div>
    )
}

export default ExchangeRate
