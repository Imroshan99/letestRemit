import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, Modal, notification } from "antd";
import { config } from "../config";
import moment from "moment";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import Spinner from "../../../reusable/Spinner";
import CustomInput from "../../../reusable/CustomInput";

export default function OTPBox(props) {
  var x;
  const ConfigReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [intervalID, setInterID] = useState(); // created a useState for intervalID

  const [reverseTimer, setReverseTimer] = useState("4m 00s");
  const [otpVerificationToken, setVerificationToken] = useState("");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
    }
  );

  useEffect(() => {
    //      console.log("OTP payload Token : ", props.state.verificationToken)
    // console.log("OTP payload Token 2 : ", otpVerificationToken)

    reverseTimerOnLoad();
  }, []);

  useEffect(() => {
    setVerificationToken(props.state.verificationToken);
  }, [props.state.verificationToken]);

  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(4, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID); // took letintervalID and stored it in useState intervalID
  };

  const onFinish = (value) => {
    form.setFields([{ name: "otp", errors: [] }]);

    const optData = {
      requestId: config.requestId,
      requestType: "VERIFYOTP",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      otpType: props.otpType,
      verificationToken: otpVerificationToken,
      otp: value.otp,
    };

    if (props.useFor == "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    if (config.IS_ENC) {
      var key = config.key;
      var iv = config.iv;
      var body = encrypt(optData, key, iv);
      var pubValue = iv.concat(key);
      var identifier = publickey(props.appState.publicKey, pubValue);

      var postData = {
        body: body,
        identifier: identifier,
      };
    } else {
      var postData = optData;
    }

    setLoader(true);
    GuestAPI.verifyOTP(postData)
      .then((res) => {
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }
        clearInterval(intervalID);
        setLoader(false);
        if (decodeData.status == "S") {
          props.setState({ isModalVisible: false });

          if (props.useFor == "signup") {
            console.log("decodeData.verifiedToken ", decodeData.verifiedToken);
            props.setState({
              verifiedToken: decodeData.verifiedToken,
              // _isShowSetPassword: true
            });
            props.checkDedupe(decodeData.verifiedToken);
          } else if (props.useFor == "login") {
            props.setState({ verifiedToken: decodeData.verifiedToken });
            props.storeLoginData(props.state.loginData);
          } else if (props.useFor == "addRecipient") {
            props.saveReceiver(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Address") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Contact") {
            setTimeout(() => {
              props.editSenderContactdtls(decodeData.verifiedToken);
            }, 1000);
          } else if (props.useFor == "Edit_Marketing") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "forgot_password") {
            props.setState({
              verifiedToken: decodeData.verifiedToken,
              _isShowSuccessMessage: true,
            });
          } else if (props.useFor == "unlock_account") {
            props.onUnlockAccountHandler();
          }
        } else {
          notification.error({ message: res.data.errorMessage });

          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {
        setLoader(false);
      });
  };

  const onClickResedOTP = async () => {
    const optData = {
      requestId: config.requestId,
      requestType: "RESENDOTP",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      verificationToken: otpVerificationToken,
      otpOption: "SM",
    };

    if (props.useFor == "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    if (config.IS_ENC) {
      var key = config.key;
      var iv = config.iv;
      var body = encrypt(optData, key, iv);
      var pubValue = iv.concat(key);
      var identifier = publickey(props.appState.publicKey, pubValue);

      var postData = {
        body: body,
        identifier: identifier,
      };
    } else {
      var postData = optData;
    }

    await GuestAPI.reSendOTP(postData)
      .then((res) => {
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }

        if (decodeData.status == "S") {
          notification.success({ message: decodeData.message });
          props.setState({ verificationToken: decodeData.verificationToken });
          setVerificationToken(decodeData.verificationToken);
          clearInterval(intervalID);
          setTimeout(() => {
            reverseTimerOnLoad();
          }, 200);
        } else {
          notification.error({ message: res.data.errorMessage });

          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
        setLoader(false);
      })
      .catch((error) => {
        setLoader(false);
      });
  };

  return (
    <div>
      <Modal centered title="Verify With OTP" visible={props.state.isModalVisible} onCancel={() => props.setState({ isModalVisible: false })} footer={null}>
        {/* {otpVerificationToken}
        <br />
        <br />
        {props.state.verificationToken} */}
        <Form form={form} onFinish={onFinish}>
          <div className="d-flex justify-content-center align-items-center">
            <div className="position-relative">
              <div className="verify-otp-box border-0 p-2 text-center">
                <h6>Please enter the 6-digit OTP sent to your registered email id</h6>
                {/* <h6>A 6 digit OTP is sent to <br /> your registered mobile number and email id</h6>
                                <div>
                                    <span>A code has been sent to</span>
                                    <small>*******{props.state.formData.mobileNo.slice(props.state.formData.mobileNo.length - 4)}</small>
                                </div> */}

                <div className="my-3">
                  <CustomInput
                    className="form-item text-start"
                    name="otp"
                    label="OTP"
                    showLabel={false}
                    size="large"
                    placeholder="OTP Number Ex. 784546"
                    required
                    validationRules={[
                      {
                        pattern: /^[0-9\b]+$/,
                        message: "Only Numbers allowed",
                      },
                    ]}
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                  />
                   
                </div>

                <div className="my-3 text-start">
                  <p className="small">OTP will expire in {reverseTimer}</p>
                </div>
                <Spinner spinning={loading} delay={500}>
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button className="btn btn-danger px-4" onClick={onClickResedOTP} type="button">
                      Resend OTP
                    </button>
                    <button className="btn btn-primary text-white px-4">Submit</button>
                  </div>
                </Spinner>
              </div>
            </div>
          </div>
        </Form>
      </Modal>
    </div>
  );
}
