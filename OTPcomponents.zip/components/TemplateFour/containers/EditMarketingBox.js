import React, { useState, useEffect } from 'react'
import { Form, Input, Select, Modal, notification, Checkbox, Radio } from 'antd';
import { config } from '../config';
import { encrypt, decrypt, publickey } from '../helpers/makeHash';
import { Row, Col } from 'react-bootstrap'
import Spinner from '../../../reusable/Spinner';
import CustomInput from '../../../reusable/CustomInput';

const { Option } = Select;

export default function EditAddressBox(props) {

    const [form] = Form.useForm();
    const [loading, setLoader] = useState(false);
    const [isSelectMarketingCommunication, setisSelectMarketingCommunication] = useState(props.state.isSameCommAddressFlag);

    useEffect(() => {
        form.setFieldsValue({
            isSameCommAddressFlag: props.state.isSameCommAddressFlag,
            marketingCommunicationMedia: props.state.marketCommunication.split("~")
        })
    }, [])

    const onFinish = (value) => {
        
        if (value.isSameCommAddressFlag == 'Y') {
            var mm = '';
            value.marketingCommunicationMedia.forEach(data => {
                mm = mm + '~' + data;
            });

            mm = mm + '~';
            props.setState({
                isSameCommAddressFlag: value.isSameCommAddressFlag,
                marketCommunication: mm
            });

        } else {
            props.setState({
                isSameCommAddressFlag: value.isSameCommAddressFlag
            });
        }

        console.log({
            isSameCommAddressFlag: value.isSameCommAddressFlag,
            marketCommunication: mm
        })
        
        props.sendOTP('EP', 'Edit_Marketing');
    }

    return (
      <div>
        <Modal centered title="Marketing Communication" visible={props.state._isShowMarketingEditModel} onCancel={() => props.setState({ _isShowMarketingEditModel: false })} footer={null}>
          <Form form={form} onFinish={onFinish}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Col md={12}>
                  <p>I agree to receive marketing communications from ICICI Bank Money2India UK about their offerings.</p>
                  <CustomInput className="form-item" name="isSameCommAddressFlag" label="Marketing communication" showLabel={false} required>
                    <Radio.Group>
                      <Radio value={"N"} onClick={() => setisSelectMarketingCommunication("N")}>
                        No
                      </Radio>
                      <Radio value={"Y"} onClick={() => setisSelectMarketingCommunication("Y")}>
                        Yes
                      </Radio>
                    </Radio.Group>
                  </CustomInput>
                  
                </Col>
                {isSelectMarketingCommunication == "Y" && (
                  <Col md={12}>
                    <CustomInput className="form-item" name="marketingCommunicationMedia" label="where you want to recieve updates and marketing communication consent." showLabel={false} required>
                      <Checkbox.Group>
                        <Checkbox value="EMAIL">E-mail</Checkbox>
                        <Checkbox value="SMS">SMS</Checkbox>
                        <Checkbox value="SOCIAL_MEDIA">Social Media</Checkbox>
                        <Checkbox value="CALL">Call</Checkbox>
                      </Checkbox.Group>
                    </CustomInput>
                     
                  </Col>
                )}

                <Spinner spinning={loading} delay={500}>
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button className="btn btn-danger px-4" onClick={() => props.setState({ _isShowMarketingEditModel: false })} type="button">
                      Cancel
                    </button>
                    <button className="btn btn-primary text-white px-4">Submit</button>
                  </div>
                </Spinner>
              </Row>
            </div>
          </Form>
        </Modal>
      </div>
    );
}
