import React from 'react'
import pageNotFound from "../../../assets/images/svg/temp4_page_not_found.svg"
function PageNotFoundFlowOne() {
    return (
        <div>
            <section className="section">
                <div className="container text-center py-5">
                    <img width={450} src={pageNotFound} alt='pageNotFound' />
                    <h3 className="mt-5 mb-3">oops! The page you requested was not found!</h3>
                    <p className="text-3 text-muted">The page you are looking for was moved, removed, renamed or might never existed.</p>
                    {/* <Link to={'/'} className="btn btn-primary text-light shadow-none px-5 m-2">Home</Link> 
                    <Link to={'/signin'} className="btn btn-outline-dark shadow-none px-5 m-2">Back</Link> */}
                </div>
            </section>
        </div>
    )
}

export default PageNotFoundFlowOne;
