import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import PageNotFoundFlowOne from "./PageNotFound";
const PageNotFound = (props) => {
    const AuthReducer = useSelector((state) => state.user);
    const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
    const templateFlow = AuthReducer.groupIdSettings?.feedback?.flow;
    return (
      <>
        <Dashboard pageTitle="Page Not Found">
          {templateFlow === "FLOW1" && (
            <PageNotFoundFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
           {templateFlow === "FLOW2" && (
            <PageNotFoundFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
          {/* {templateFlow === "FLOW2" && (
            <TransactionAction2
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
        </Dashboard>
      </>
    );
  };
  
  export default PageNotFound;
  