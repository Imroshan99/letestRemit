import React from "react";
import { useSelector } from "react-redux";
import RecipientList1 from "../RecipientList/RecipientListFlow1/RecipientList";
import RecipientList2 from "../RecipientList/RecipientListFlow2/RecipientList";

import Dashboard from "../Layouts/Dashboard";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const RecipientList = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.recipientModule?.recipientList?.flow;

  return (
    <>
      <Dashboard pageTitle="My Receiver List">
        {templateFlow === "FLOW1" && (
          <RecipientList1
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
        {templateFlow === "FLOW2" && (
          <RecipientList2
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
      </Dashboard>
    </>
  );
};

export default RecipientList;
