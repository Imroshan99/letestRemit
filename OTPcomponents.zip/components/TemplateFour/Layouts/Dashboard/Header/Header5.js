/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import PermIdentityOutlinedIcon from "@mui/icons-material/PermIdentityOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import { useSelector } from "react-redux";
import { useState } from "react";
import UserMenu from "../../../user/UserMenu";
import { Link, NavLink, useNavigate } from "react-router-dom";
export default function Header5() {
  const AuthReducer = useSelector((state) => state.user);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const navigate = useNavigate();

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };
  return (
    <>
      <header
        className="header-bg"
        style={{
          backgroundImage: `url(${require("../../../../../assets/images/home-bg/mf.webp")})`,
        }}
      >
        <div className="overlay"></div>
        <div className="container pt-3">
          <nav className="navbar navbar-expand-lg navbar-light">
            <Link className="logo" to="/">
              <img src={require("../../../../../assets/images/logos/" + AuthReducer.groupId + "_logo.png")} height="48px" alt="Logo" />
            </Link>
            {AuthReducer?.isLoggedIn && (
              <>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="true" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                  <div class="navbar-nav ms-auto d-flex align-items-center">
                    <NavLink className="nav-item navTitles" to="/new-transaction">
                      New Transcation
                    </NavLink>
                    <NavLink className="nav-item navTitles2" to="/my-recipient">
                      Receivers
                    </NavLink>
                    <NavLink className="nav-item navTitles2 me-3" to="/my-bank-accounts">
                      Bank Accounts
                    </NavLink>
                    {/* <a class="nav-item" href="#">
                    <img src={require("../../../../../assets/images/flags/profile.png")} />
                  </a> */}
                    <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                      <Avatar
                        alt={AuthReducer.userFullName}
                        // {...stringAvatar(AuthReducer.userFullName)}
                      >
                        <PermIdentityOutlinedIcon />
                      </Avatar>
                    </IconButton>
                    <UserMenu anchorElUser={anchorElUser} handleCloseUserMenu={handleCloseUserMenu} />
                  </div>
                </div>
              </>
            )}
          </nav>
          <hr />
        </div>
      </header>
    </>
  );
}
