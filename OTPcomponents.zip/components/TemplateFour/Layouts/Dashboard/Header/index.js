import { useSelector } from "react-redux";
import Header1 from "./Header1";
import Header2 from "./Header2";
import Header3 from "./Header3";
import Header4 from "./Header4";
import Header5 from "./Header5";
import Header6 from "./Header6";

export default function Header() {
  const groupConfig = useSelector((state) => state.user);
  const headerTemplate = groupConfig.groupIdSettings?.theme?.Header;
  return (
    <>
      {headerTemplate === "Header1" && <Header1 />}
      {headerTemplate === "Header2" && <Header2 />}
      {headerTemplate === "Header3" && <Header3 />}
      {headerTemplate === "Header4" && <Header4 />}
      {headerTemplate === "Header5" && <Header5 />}
      {headerTemplate === "Header6" && <Header6 />}
    </>
  );
}
