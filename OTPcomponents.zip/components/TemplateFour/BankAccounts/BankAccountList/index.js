import React from "react";
import { useSelector } from "react-redux";
import BankAccountListFlow1 from "./BankAccountListFlow1/BankAccountList";
import Dashboard from "../../Layouts/Dashboard";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const BankAccountList = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.bankAccount?.bankAccountList?.flow;

  return (
    <>
      <Dashboard pageTitle="Bank Account List">
        {templateFlow === "FLOW1" && (
          <BankAccountListFlow1
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
        {templateFlow === "FLOW2" && (
          <BankAccountListFlow1
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
      </Dashboard>
    </>
  );
};

export default BankAccountList;
