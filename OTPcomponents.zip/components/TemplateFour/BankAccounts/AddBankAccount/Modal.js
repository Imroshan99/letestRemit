import React from "react";
import { useSelector } from "react-redux";
import AddBankAccountFlow1 from "./AddBankAccountFlow1/AddBankAccount";
import AddBankAccountFlow2 from "./AddBankAccountFlow2/AddBankAccount";
import { Modal } from "antd";

const AddBankAccountModal = (props) => {
  const groupConfig = useSelector((state) => state.user);
  const templateFlow =
    groupConfig.groupIdSettings?.bankAccount?.addBankAccount?.flow;
  return (
    <Modal
      centered
      visible={props.visible}
      onCancel={() => props.setVisible(false)}
      forceRender={true}
      footer={null}
      width={500}
    >
      {templateFlow === "FLOW1" && (
        <AddBankAccountFlow1
          appState={props.appState}
          manageAuth={props.manageAuth}
          accountsList={props.accountsList}
          setVisible={props.setVisible}
          visible={props.visible}
        />
      )}
      {templateFlow === "FLOW2" && (
        <AddBankAccountFlow2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </Modal>
  );
};

export default AddBankAccountModal;
