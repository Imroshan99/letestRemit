import React from "react";
import LoginForm from "../Login/LoginForm";
import AuthTemplate from "../Layouts/Auth";

const Login = (props) => {
  return (
    <>
      <AuthTemplate>
        <LoginForm appState={props.appState} manageAuth={props.manageAuth} />
      </AuthTemplate>
    </>
  );
};

export default Login;
