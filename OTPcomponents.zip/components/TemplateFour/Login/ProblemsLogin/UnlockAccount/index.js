import AuthTemplate from "../../../Layouts/Auth";
import UnlockAccountFlowOne from "./UnlockAccountFlowOne";

const UnlockAccount = (props) => {
  return (
    <AuthTemplate>
      <UnlockAccountFlowOne />
    </AuthTemplate>
  );
};

export default UnlockAccount;
