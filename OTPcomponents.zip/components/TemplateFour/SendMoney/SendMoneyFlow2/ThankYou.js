import React, { useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import moment from "moment";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { config } from "../../../../config";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import useHttp from "../../../../hooks/useHttp";

// import Printer, { print } from 'react-pdf-print'

function ThankYou(props) {
  const ids = ["1"];
  const [isFav, setFav] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  // const txnReceiptDetail = {
  //     "responseId": "2420653",
  //     "requestId": "1643778633689WqFRBRi",
  //     "responseType": "TXNDETAILS",
  //     "groupId": "IUK",
  //     "token": null,
  //     "status": "S",
  //     "message": "Success",
  //     "errorCode": null,
  //     "errorMessage": null,
  //     "errorList": null,
  //     "txnRefNumber": "UK1Z1265174",
  //     "rgtn": "55341408240042",
  //     "sendModeCode": "CIP",
  //     "programCode": "FERINST",
  //     "paymodeType": "GlobalPay",
  //     "sendCountry": "GB-GBP",
  //     "sendAmount": "800.00",
  //     "sendAmountText": "Eight Hundred and Two",
  //     "amountPayable": "802.00",
  //     "exRateWithoutPromo": "19.09",
  //     "exRate": "12.09",
  //     "promoBenefit": "0.00",
  //     "recvCountry": "IN-INR",
  //     "recvAmount": "9672.00",
  //     "receiveAmountText": "Nine Thousand  Six Hundred and Seventy Two",
  //     "receiverNickName": "175356",
  //     "receiverName": "NITIN  KADAM",
  //     "recvBankName": "ICICI BANK LTD",
  //     "recvAccNumber": "963258741231",
  //     "recvAddress": "",
  //     "recvMobileNo": "-",
  //     "recvBankBranchName": "MUMBAI - LBS MARG KURLA, MAHARASHTRA",
  //     "recvModeCodeDesc": "Bank Account Credit",
  //     "recvModeCode": "DC",
  //     "bookingDate": "2022-02-02 10:38:56",
  //     "bookingDateTZ": "2022-02-02 05:08:56",
  //     "validityDate": "2022-02-04",
  //     "payDate": "2022-02-02 10:39:30",
  //     "payDateTZ": "2022-02-02 05:09:30 +00:00",
  //     "transactionStatusCode": "181",
  //     "transactionStatus": "Deal Utilized",
  //     "transactionSubStatus": "N.A.",
  //     "senderBankName": "",
  //     "routingNumber": "",
  //     "senderAccountNo": "",
  //     "expDeliveryDate": "2022-02-02 07:09 AM",
  //     "expDeliveryDateTZ": "2022-02-02 01:39:00.0",
  //     "showCancelButton": "",
  //     "pointEarnValue": "48.36",
  //     "pointsEarn": "",
  //     "purpose": "6",
  //     "purposeDesc": "Family Maintainance test",
  //     "traceNo": null,
  //     "recordToken": "",
  //     "bankAcc_labelCode": null,
  //     "bankAcc_captionCode": null,
  //     "bankAcc_valueCode": null,
  //     "customerName": "DARSHANA NIINAWE",
  //     "customerAddress1": "Mytholmes Lane",
  //     "customerAddress2": "Haworth",
  //     "customerState": "West Yorkshire",
  //     "customerCity": "Keighley",
  //     "customerZipCode": "BD22 8EZ",
  //     "customerMobileNo": "44-7898739638",
  //     "recvAddress2": "",
  //     "recvState": "",
  //     "recvCity": "MAHAKALPADA",
  //     "recvZipCode": "",
  //     "transaferFee": "2.0",
  //     "convertedAmount": "9672.00",
  //     "gst": "0.00",
  //     "programName": "Debit Card",
  //     "transferMessage": "Transfer Successful",
  //     "isCategoryPromo": "N",
  //     "feeTax": "0.00",
  //     "promoCode": "",
  //     "bankCode": "",
  //     "mobileWalletName": "",
  //     "bookingDateTwoHrs": "2022-02-02 12:38:56.75"
  // };

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };
    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from faviorate successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to faviorate successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const onClickprintPDF = () => {
    var doc = new jsPDF();
    doc.setTextColor(19, 184, 43);
    doc.text(80, 10, "Transfer Successful");
    doc.setTextColor(0, 0, 0);
    doc.text(
      40,
      20,
      `TRANSFER TRACKING NUMBER - ${txnReceiptDetail.txnRefNumber}`
    );
    // doc.setTextBackground(165, 0, 0);
    // doc.setTextColor(255, 0, 0); //set font color to red
    doc.text(70, 40, "TRANSFER SUMMARY");
    doc.setFont("times");
    doc.text(40, 50, "Transfer Amount");
    doc.text(110, 50, `${txnReceiptDetail.amountPayable} GBP`);
    doc.text(40, 60, " Sent to");
    doc.text(110, 60, `${txnReceiptDetail.receiverName} `);
    doc.text(40, 70, " Expected to reach on");
    doc.text(
      110,
      70,
      `${moment(txnReceiptDetail.expDeliveryDate).format(
        "YYYY-MM-DD: HH:MM A"
      )} `
    );
    doc.setTextColor(255, 0, 0); //set font color to red

    doc.text(11, 100, "Kindly note:");
    doc.setTextColor(0, 0, 0); //set font color to red
    doc.setFontSize(13);
    doc.text(
      11,
      110,
      `• The Tracking number ${txnReceiptDetail.txnRefNumber} is unique and is valid only for this transaction.`
    );
    doc.text(
      11,
      115,
      "  DO NOT PRECEDE the Tracking Number with any other comment.In case the Tracking number"
    );
    doc.text(
      11,
      120,
      "  is missing or incorrectly provided  in your transfer payment details, your funds may get rejected "
    );
    doc.text(11, 125, "  or processing may get delayed.");
    doc.text(
      11,
      135,
      "• Please ensure that you send exactly the same amount as confirmed in the Amount/Currency field above."
    );
    doc.text(
      11,
      140,
      "  This amount should be lower than or equal to your Net banking funds transfer limit (if any)"
    );
    doc.text(11, 145, "  as set-up for your Remitting Bank account.");
    doc.text(
      11,
      155,
      "• Once you initiate the money transfer from your local bank account to ICICI Bank"
    );
    doc.text(
      11,
      160,
      "  Correspondent Bank account using your local bank’s Internet Banking facility, depending upon "
    );
    doc.text(
      11,
      165,
      "  the electronic clearing used by your local bank to transfer the money and the associated clearing time,"
    );
    doc.text(
      11,
      175,
      "• ICICI Bank will typically receive the funds within 1 working day."
    );
    doc.text(
      11,
      180,
      "  ICICI Bank will credit the funds into the receivers ICICI Bank Account within 1 working day of"
    );
    doc.text(
      11,
      185,
      "  ICICI Bank receiving the money. Timelines exclude banking holidays as well as Saturday and Sunday"
    );
    doc.text(
      11,
      190,
      "  in the remitting country and in India. Please Click here to view the list of banking holidays in"
    );
    doc.text(11, 195, "  United Kingdom and in India.");
    doc.text(
      11,
      205,
      "• The INR amount disbursed to the beneficiary (as per your remittance request) will be net of the Conversion Service Tax."
    );
    doc.text(
      11,
      215,
      "• Service Tax on currency conversion is applicable slab-wise. This will be calculated based on the actual"
    );
    doc.text(
      11,
      220,
      "  rate at which the funds are converted, as the Service tax is applicable on converted INR value."
    );
    doc.text(
      11,
      225,
      "  Click here to know the slab wise service tax structure.Read Less"
    );

    doc.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
  };

  return (
    <div className="container p-5">
      <section className="text-center">
        <h3>Transfer Successful</h3>
        <h5>TRANSFER TRACKING NUMBER - {txnReceiptDetail.txnRefNumber}</h5>
      </section>

      <section className="text-center">
        <div className="text-justify bg-light p-3 mt-3">
          <h3>TRANSFER SUMMARY</h3>
          <div className="row">
            <div className="col-md-6">Transfer Amount</div>
            <div className="col-md-6">
              <b>{`${txnReceiptDetail.amountPayable}`} ​GBP</b>
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">Sent to</div>
            <div className="col-md-6">
              <b>{txnReceiptDetail.receiverName}</b>
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">Expected to reach on</div>
            <div className="col-md-6">
              <b>
                {moment(txnReceiptDetail.expDeliveryDate).format(
                  "YYYY-MM-DD: HH:MM A"
                )}
              </b>
            </div>
          </div>
        </div>
      </section>
      <section className="bg-light p-3 mt-3">
        <h5 className="mx-3">Kindly note:</h5>
        <ul>
          <li>
            The Tracking number {txnReceiptDetail.txnRefNumber} is unique and is
            valid only for this transaction.DO NOT PRECEDE the Tracking Number
            with any other comment.In case the Tracking number is missing or
            incorrectly provided in your transfer payment details, your funds
            may get rejected or processing may get delayed.{" "}
          </li>
          <li>
            Please ensure that you send exactly the same amount as confirmed in
            the Amount/Currency field above. This amount should be lower than or
            equal to your Net banking funds transfer limit (if any) as set-up
            for your Remitting Bank account.
          </li>
          <li>
            Once you initiate the money transfer from your local bank account to
            ICICI Bank Correspondent Bank account using your local bank’s
            Internet Banking facility, depending upon the electronic clearing
            used by your local bank to transfer the money and the associated
            clearing time, ICICI Bank will typically receive the funds within 1
            working day.
          </li>
          <li>
            ICICI Bank will credit the funds into the receiver's ICICI Bank
            Account within 1 working day of ICICI Bank receiving the money.
          </li>
          <li>
            {" "}
            Timelines exclude banking holidays as well as Saturday and Sunday in
            the remitting country and in India. Please Click here to view the
            list of banking holidays in United Kingdom and in India.
          </li>
          <li>
            {" "}
            The INR amount disbursed to the beneficiary (as per your remittance
            request) will be net of the Conversion Service Tax.
          </li>
          <li>
            {" "}
            Service Tax on currency conversion is applicable slab-wise. This
            will be calculated based on the actual rate at which the funds are
            converted, as the Service tax is applicable on converted INR value.
            Click here to know the slab wise service tax structure.Read Less
          </li>
        </ul>
      </section>
      <ht />

      <section className="text-center">
        <p>
          Your tracking ID is <b>{txnReceiptDetail.txnRefNumber}</b>
        </p>
        <p>
          "You can use this ID to track your transaction once you have initiated
          a transfer at your local bank.",
        </p>
      </section>

      <section className="my-3 text-center">
        <button
          className="border-0 bg-none "
          onClick={onClickprintPDF}
          type="button"
        >
          {" "}
          <LocalPrintshopIcon className="mx-2" />
          View and Download
        </button>
        <span className="mx-4 fs-4">|</span>
        <button className="border-0 bg-none">
          {!isFav ? (
            <StarBorderIcon className="mx-2" onClick={onClickFavourite} />
          ) : (
            <StarIcon className="mx-2" onClick={onClickFavourite} />
          )}
          Add To Favourite
        </button>
      </section>
      <section className="text-center">
        <button
          className="btn my-4 "
          type="button"
          onClick={() =>
            props.setState({
              isStep: 1,
              promoValueWithDesc: "",
              isSelectedBankTransfer: false,
              _isScheduleTransaction: false,
              sendAccId: "",
              achAccId: "",
              accountNo: "",
            })
          }
        >
          Make Another Transfer
        </button>
      </section>
    </div>
  );
}

export default ThankYou;
