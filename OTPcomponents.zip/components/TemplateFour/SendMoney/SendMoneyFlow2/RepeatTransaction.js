import TranctionAction from "./TranctionAction";
import { useLocation } from "react-router-dom";

function RepeatTranscation(props) {
  const location = useLocation();
  const transactionDetails = {
    rgtn: location.state.rgtn,
    txnRefNo : location.state.txnRefNo
  };
  console.log("Props ", props);
  return (
    <div>
      <TranctionAction
        appState={props.appState}
        manageRefreshToken={props.manageRefreshToken}
        transcationType="REPEAT"
        repeatTranscationDetails={transactionDetails}
      />
    </div>
  );
}

export default RepeatTranscation;
