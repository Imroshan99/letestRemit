import React, { createRef, useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import HomeIcon from "@mui/icons-material/Home";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useSelector } from "react-redux";

import { Link } from "react-router-dom";
import useHttp from "../../../../../hooks/useHttp";

function KCBBankThankYou(props) {
  const AuthReducer = useSelector((state) => state.user);

  const invRef = createRef();

  const [isFav, setFav] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };

    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status === "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from favourite successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to favourite successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const onClickprintPDF = () => {
    var doc = new jsPDF();
    doc.text(
      10,
      10,
      `Follow the steps below to complete your transfer to ${txnReceiptDetail.recvBankName}`
    );
    doc.setFontSize(16);
    doc.setTextColor(255, 165, 0);
    doc.text(10, 20, "Step 1");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(13);
    doc.text(
      10,
      27,
      `Login to your bank's internet banking. Go to funds transfer and select your`
    );
    doc.text(
      10,
      33,
      `account number ${txnReceiptDetail.recvAccNumber} to send funds.`
    );
    doc.setFontSize(16);
    doc.setTextColor(255, 165, 0);
    doc.text(10, 41, "Step 2");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(13);
    doc.text(
      10,
      47,
      `Initiate a transfer by inputting the below mandatory details in the corresponding fields:`
    );
    doc.setFontSize(14);
    doc.setFont("times");
    doc.text(10, 60, "Transfer Amount");
    doc.text(
      110,
      60,
      `${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`
    );
    doc.text(10, 70, "Recipient Name:");
    doc.text(110, 70, `${txnReceiptDetail.receiverName}`);
    doc.text(10, 80, "Recipient Bank:");
    doc.text(110, 80, `${txnReceiptDetail.recvBankName} `);
    doc.text(10, 90, "Recipient Bank Clearing / Sort Code:");
    doc.text(110, 90, `600004 `);
    doc.text(10, 100, "Recipient Account Number:");
    doc.text(110, 100, `${txnReceiptDetail.recvAccNumber}`);
    doc.text(10, 110, "Purpose of Payment:");
    doc.text(110, 110, `${txnReceiptDetail.purposeDesc}`);
    doc.text(10, 120, "Mode of Payment:");
    doc.text(110, 120, `${txnReceiptDetail.recvModeCodeDesc}`);
    // doc.setTextBackground(165, 0, 0);
    doc.setTextColor(255, 0, 0); //set font color to red
    doc.text(
      11,
      132,
      `Post online transfer, ${txnReceiptDetail.recvBankName} will be credited within 1-3 working days.`
    );
    doc.setTextColor(255, 0, 0); //set font color to red

    doc.text(11, 140, "Kindly note:");
    doc.setTextColor(0, 0, 0); //set font color to red
    doc.setFontSize(13);
    doc.text(
      11,
      150,
      `• The Tracking number ${txnReceiptDetail.txnRefNumber} is unique and is valid only for this transaction.`
    );
    doc.text(
      11,
      155,
      ` DO NOT PRECEDE the Tracking Number with any other comment. In case the Tracking number is `
    );
    doc.text(
      11,
      160,
      " number is missing or incorrectly provided in your transfer payment details, your funds may"
    );
    doc.text(11, 165, " get rejected or processing may get delayed.");

    doc.text(
      11,
      175,
      "• Please ensure that you send exactly the same amount as confirmed in the Amount/Currency field above. "
    );
    doc.text(
      11,
      180,
      "  This amount should be lower than or equal to your Net banking funds transfer limit (if any) as set-up"
    );
    doc.text(11, 185, "  for your Remitting Bank account.");

    doc.text(
      11,
      195,
      "• Once you initiate the money transfer from your local bank account to Bank Correspondent Bank "
    );
    doc.text(
      11,
      200,
      "  account using your local bank’s Internet Banking facility, depending upon the electronic clearing "
    );
    doc.text(
      11,
      205,
      "  used by your local bank to transfer the money and the associated clearing time, Bank will "
    );
    doc.text(11, 210, "  typically receive the funds within 1 working day.");

    doc.text(
      11,
      220,
      "• ICICI Bank will typically receive the funds within 1 working day."
    );
    doc.text(
      11,
      225,
      "  ICICI Bank will credit the funds into the receivers ICICI Bank Account within 1 working day of"
    );
    doc.text(
      11,
      230,
      "  ICICI Bank receiving the money. Timelines exclude banking holidays as well as Saturday and Sunday"
    );
    doc.text(
      11,
      235,
      "  in the remitting country and in India. Please Click here to view the list of banking holidays in"
    );
    doc.text(11, 240, "  United Kingdom and in India.");

    doc.text(
      11,
      250,
      "• Timelines exclude banking holidays as well as Saturday and Sunday in the remitting country and "
    );
    doc.text(
      11,
      255,
      "  in India. Please Click here to view the list of banking holidays in United Kingdom and in India."
    );

    doc.text(
      11,
      265,
      "• The INR amount disbursed to the beneficiary (as per your remittance request) will be net of the "
    );
    doc.text(11, 270, "  Conversion Service Tax. ");

    doc.text(
      11,
      280,
      "• Service Tax on currency conversion is applicable slab-wise. This will be calculated based on the"
    );
    doc.text(
      11,
      285,
      "  actual rate at which the funds are converted, as the Service tax is applicable on converted INR "
    );
    doc.text(
      11,
      290,
      "  value. Click here to know the slab wise service tax structure.Read Less"
    );

    doc.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
  };
  const savePDF = () => {
    // const input = document.getElementById("divToPrint");

    html2canvas(invRef.current).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
    });
  };
  return (
    <div className="container p-5">
      <div className="row">
        <div className="col-md-1"></div>
        <div className="col-md-10">
          <section className="text-center">
            <h2>Transaction Booked Successfully</h2>
          </section>
          <section className="my-3 text-center">
            <Link className="btn btn-secondary mx-1  mt-2" to={"/"}>
              <HomeIcon />
            </Link>

            <button
              className="btn btn-secondary mx-1  mt-2"
              onClick={savePDF}
              type="button"
            >
              <LocalPrintshopIcon className="me-2" />
              Download Receipt
            </button>

            <button className="btn btn-secondary mx-1  mt-2">
              {!isFav ? (
                <StarBorderIcon className="me-2" onClick={onClickFavourite} />
              ) : (
                <StarIcon className="me-2" onClick={onClickFavourite} />
              )}
              Add To Favourite
            </button>

            <Link className="btn btn-secondary mx-1 mt-2" to={"/"}>
              <AddCircleOutlineIcon className="me-2" />
              Make Another Transfer
            </Link>
          </section>
          <section className="bg-light p-3 mt-3" ref={invRef}>
            <div>
              <img
                src={require("../../../../../assets/images/logos/" +
                AuthReducer.groupId + "_logo.png")}
                height="48px"
              />
            </div>
            <p className="mt-3">
              Money transfer request to KCB Account authorized. <br />
              Transaction Status- Transaction Booked Successfully and awaiting
              payment. <br />
              Your KCB Transaction No. (KCBTN) :
              <b>{txnReceiptDetail.txnRefNumber}</b>
            </p>
            <p className="mt-3">
              <table className="table">
                <tbody>
                  <tr>
                    <td>
                      <strong>Transaction Number</strong>
                    </td>
                    <td>{txnReceiptDetail.txnRefNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Date of Booking:</strong>
                    </td>
                    <td>{txnReceiptDetail.bookingDate}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transfer Amount:</strong>
                    </td>
                    <td>{`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Name:</strong>
                    </td>
                    <td>{txnReceiptDetail.receiverName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Bank Branch:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvBankBranchName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Account Number:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvAccNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Send Mode:</strong>
                    </td>
                    <td>{txnReceiptDetail.sendModeCode}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transaction Status:</strong>
                    </td>
                    <td>{txnReceiptDetail.transactionStatus}</td>
                  </tr>
                </tbody>
              </table>
            </p>
            <p>
              <strong>KCB Remit Payment Policy &amp; Error Resolution</strong>
              <br />
              You have a right to dispute errors in your transaction. If you
              think there is an error, contact us within 180 days at
              ContactNumber or EmailID. You can also contact us for a written
              explanation of your rights. You can cancel the transfer request
              within 30 minutes of instructing us using the Cancel option. The
              option will not be available after 30 minutes of placing the
              transfer request. <br />
              For questions or complaints about KCB Remit Online, contact:
              contactcentre@kcbgroup.com
            </p>

            <p>
              <strong>Department of Financial Services</strong>
              <br />
              (800) 342-3736 (Monday through Friday, 8:30 AM to 4:30 PM). <br />
              (Local calls can be made to (212) 480-6400 <br />
              <strong>Consumer Financial Protection Bureau</strong> <br />
              855-411-2372 <br />
              855-729-2372 (TTY/TDD) <br />
              www.consumerfinance.gov <br />
            </p>
            <p>
              If you think there has been an error or problem with your
              remittance transfer: <br />
              Error Resolution &amp; Cancellation: <br />
              Call us at +254711087000/+254732187000 <br />
              Write to us at: contactcentre@kcbgroup.com
              <br />
              KCB Kenya Address or <br />
              E-mail us at contactcentre@kcbgroup.com <br />
              WhatsApp : +254711087087
              <br />
              SMS : 22522 [Local Kenya Numbers only]
              <br />
              You must contact us within 180 days of the date we promised to you
              that funds would be made <br />
              available to the recipient. When you do, please tell us: <br />
              <ol>
                <li>Your name and login ID</li>
                <li>
                  The error or problem with the transfer, and why you believe it
                  is an error or problem
                </li>
                <li>The Remittance Transaction Reference</li>
              </ol>
              Number We will determine whether an error occurred within 90 days
              after you contact us and we will correct any error promptly. We
              will tell you the results within three business days after
              completing our investigation. If we decide that there was no
              error, we will send you a written explanation. You may ask for
              copies of any documents we used in our investigation. <br />
              What to do if you want to cancel a remittance transfer: <br />
              You have the right to cancel a remittance transfer instruction. In
              order to cancel, you can cancel the instruction by logging into
              your KCB Remit account and using the 'Cancel' option. You can also
              contact us at the phone number within 30 minutes of payment for
              the transfer. When you contact us, you must provide us with
              information to help us identify the transfer you wish to cancel
              including the amount and the reference number under which the
              funds were sent. Upon cancellation of the transfer instruction, we
              will not debit your US account registered with us.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

export default KCBBankThankYou;
