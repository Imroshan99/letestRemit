import React, { useEffect } from "react";
import { Form, Select, Row, Col, Space, Radio } from "antd";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import CustomInput from "../../../../reusable/CustomInput";
const { Option } = Select;

export default function SelectAccountDetail(props) {
  const AuthReducer = useSelector((state) => state.user);
  const [form1] = Form.useForm();

  useEffect(() => {
    form1.setFieldsValue({
      recipient: props.state.receiverName === "" ? undefined : props.state.receiverName,
      isBankTransfer: props.state.isSelectedBankTransfer ? "Bank Transfer" : "",
      sourceAccount: props.state.senderName === "" ? undefined : props.state.senderName,
    });
    console.log("data=>", props.state.isSelectedBankTransfer);
  }, []);

  const handleChangeRecipent = (rec) => {
    let recipent = JSON.parse(rec);
    props.setState({
      receiverName: `${recipent.firstName} ${recipent.lastName}`,
      receiverAccount: recipent.accountNo,
      nickName: recipent.nickName,
    });
  };

  const handleChangeBankAccount = (acc) => {
    let account = JSON.parse(acc);
    console.log("account", account);
    props.setState({
      sendAccId: props.state.groupId == "KCB" ? "" : account.sendAccId,
      achAccId: props.state.groupId == "KCB" ? account.aCHAccId : "",
      accountNo: account.accountNo,
      senderName: account.accountHolderName,
    });
    // ${rec.firstName} ${rec.lastName} ${rec.accountNo}
  };

  const onFinishAccount = (value) => {
    props.setState({ isStep: 3 });
    props.getPurposeLists();
  };

  return (
    <div>
      <Form form={form1} onFinish={onFinishAccount}>
        <div className="row">
          {/* <label className="form-label">Select Recipient</label> */}
          <div className="col-12 col-md-4">
            <CustomInput className="form-item" name="recipient" type="select" required onChange={handleChangeRecipent} label="Select Recipient" placeholder="Select Recipient">
              {props.state.receiverLists.map((rec, i) => {
                return <Option key={i} value={JSON.stringify(rec)}>{`${rec.firstName} ${rec.lastName} ${rec.accountNo} (${rec.bankName})`}</Option>;
              })}
            </CustomInput>
            {/* <Form.Item
              className="form-item"
              name="recipient"
              rules={[
                { required: true, message: "Please select your recipient." },
              ]}
            >
              <Select
                className="w-100"
                onChange={handleChangeRecipent}
                placeholder="Select Recipient"
              >
                {props.state.receiverLists.map((rec, i) => {
                  return (
                    <Option
                      key={i}
                      value={JSON.stringify(rec)}
                    >{`${rec.firstName} ${rec.lastName} ${rec.accountNo} (${rec.bankName})`}</Option>
                  );
                })}
              </Select>
            </Form.Item> */}
          </div>
          <div className="col-12 col-md-8 text-start">
            <Link
              to={{
                pathname: "/add-recipient",
              }}
              state={{
                fromPage: "NEW_TRANSACTION",
                fromPageState: {
                  sendAmount: props.state.sendAmount,
                  activeStep: 2,
                },
              }}
              className="btn btn-primary-light"
            >
              Add New Receiver
            </Link>
          </div>
        </div>

        <div>
          <Form.Item className="form-item" name="isBankTransfer" rules={[{ required: true, message: "Please select your Bank Transfer." }]}>
            <Radio.Group>
              <Space direction="Horizontaly">
                <Radio
                  value={"Bank Transfer"}
                  onClick={() => {
                    props.setState({ isSelectedBankTransfer: true });
                  }}
                >
                  Bank Transfer
                </Radio>
              </Space>
            </Radio.Group>
          </Form.Item>
        </div>

        {props.state.isSelectedBankTransfer && (
          <div className="row">
            <div className="col-12 col-md-4">
              <CustomInput className="form-item" name="sourceAccount" label="Select Sender Account" type="select" required onChange={handleChangeBankAccount} placeholder="Select Sender Account">
                {props.state.bankAccountLists.map((acc, i) => {
                  return <Option key={i} value={JSON.stringify(acc)}>{`${acc.accountHolderName} ${acc.accountNo}`}</Option>;
                })}
              </CustomInput>
              {/* <Form.Item
                className="form-item"
                name="sourceAccount"
                rules={[
                  {
                    required: true,
                    message: "Please select your source account.",
                  },
                ]}
              >
                <Select className="w-100" onChange={handleChangeBankAccount} placeholder="Select Sender Account">
                  {props.state.bankAccountLists.map((acc, i) => {
                    return <Option key={i} value={JSON.stringify(acc)}>{`${acc.accountHolderName} ${acc.accountNo}`}</Option>;
                  })}
                </Select>
              </Form.Item> */}
            </div>
            <div className="col-12 col-md-8 text-start">
              <Link
                to={{
                  pathname: "/add-bank-account",
                }}
                state={{
                  fromPage: "NEW_TRANSACTION",
                  fromPageState: {
                    sendAmount: props.state.sendAmount,
                    activeStep: 2,
                  },
                }}
                className="btn btn-primary-light"
              >
                Add New Bank Account
              </Link>
            </div>
          </div>
        )}
        <p className="mt-3">
          Please Note: There is transfer fee of {props.state.totalFee} {AuthReducer.sendCurrencyCode} applied on this transaction {props.state.isSelectedBankTransfer}
        </p>
        <div className="d-flex my-2">
          <button className="btn btn-primary text-white px-5" onClick={() => props.setState({ isStep: 1 })}>
            Back
          </button>
          <button htmlType="submit" className="btn btn-primary text-white px-5 mx-4">
            Proceed
          </button>
        </div>
      </Form>
    </div>
  );
}
