/* eslint-disable jsx-a11y/alt-text */
import "./SendMoney.css";
import Header from "../../layout/Header";
import svg1 from "../../../../assets/images/svg/left-svg.svg";
import svg2 from "../../../../assets/images/svg/right-svg.svg";
import { Steps } from "antd";
import { useState } from "react";
import AddRecipient from "../recipient/AddRecipient";

const { Step } = Steps;

let SendMoney = (props) => {
  const [addRecipentModal, setAddRecipentModal] = useState(false);
  const [IFSC, setIFSC] = useState("");
  console.log("State", props.appState.isLoggedIn);

  return (
    <div className="SendMoney-Container">
      <Header />
      
      <div className="SendMoney-Container-User-Container">
        <div className="SendMoney-Container-User-Centered-Container"></div>
      </div>
      <div className="SendMoney-Stepper-Container">
        <div className="SendMoney-Stepper-Centered-Container">
          <Steps className="abc" size="small" current={1}>
            <Step title="Finished" icon={<div />} />
            <Step title="In Progress" icon={<div />} />
            <Step title="Waiting" icon={<div />} />
          </Steps>
        </div>
      </div>
      <div className="SendMoney-Container-Form-Container">
        <button
          className="Add-Recipent"
          onClick={() => setAddRecipentModal(true)}
        >
          Add Recipient
        </button>
        <img className="svg1" src={svg1} height="60%" />
        <img className="svg2" src={svg2} height="60%" />
        {addRecipentModal && (
          <AddRecipient
            serIFSC={setIFSC}
            setAddRecipentModal={setAddRecipentModal}
          />
        )}
      </div>
    </div>
  );
};

export default SendMoney;
