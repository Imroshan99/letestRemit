import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
} from "antd";
import moment from "moment";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import useHttp from "../../../../hooks/useHttp";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../../apis/GuestAPI";
import Spinner from "../../../../reusable/Spinner";

const { Option } = Select;
const { TextArea } = Input;

const exchangeRateOptions = [
  { code: 1, name: "Indicative" },
  { code: 2, name: "Fixed Rate" },
];

export default function ScheduleReminder(props) {
  const [mainShow, setMainShow] = useState(true);
  const [successShow, setSuccessShow] = useState(false);
  const [errorShow, setErrorShow] = useState(false);

  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);

  const [form] = Form.useForm();

  const defaultSettings = ConfigReducer.groupIdSettings.default;

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      innerTitle: "Send Money",
      promoCode: "",
      programCode: defaultSettings.programCode,

      receiverCountryLists: [],
      receiverLists: [],
      bankAccountLists: [],
      nickName: "NEWRECV",
      sendAccId: "",
      startDate: "",
      sendingAmount: "",
      message: "",
      loading: false,
    }
  );

  const hookGetReceiverLists = useHttp(TransactionAPI.receiverLists);
  const hookGetReceiverCountryLists = useHttp(GuestAPI.receiverCountryList);
  const hookGetBankAccountLists = useHttp(TransactionAPI.getBankAccountLists);
  const hookScheduleTransactionReminder = useHttp(
    TransactionAPI.scheduleTransactionReminder
  );

  useEffect(() => {
    getReceiverNameLists();
    getReceiverCountryLists();
    getBankAccountLists();
  }, []);

  const getReceiverNameLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "VALID",
    };

    setState({ loading: true });
    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ receiverLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const getReceiverCountryLists = () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    setState({ loading: true });
    hookGetReceiverCountryLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ receiverCountryLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  // CIP Mode
  const getBankAccountLists = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      countryCode: AuthReducer.sendCountryCode,
      countryId: undefined,
      favouriteFlag: "1",
      recordsPerRequest: "15",
      startIndex: "0",
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetBankAccountLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ bankAccountLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const onSubmitScheduleTransactionReminder = () => {
    setState({ loading: true });
    let payload = {
      requestType: "ScheduleTxnReminder",
      userId: state.userID,
      recvNickName: state.nickName,
      sendAccId: state.sendAccId,
      startDate: state.startDate,
      amount: state.sendingAmount,
      sendCountryCurrency: AuthReducer.sendCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCountryCurrency: AuthReducer.recvCurrencyCode,
      sendModeCode: "CIP",
      programCode: "FER",
      personalMsg: state.message,
    };
    hookScheduleTransactionReminder.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setMainShow(false);
        setSuccessShow(true);
        setErrorShow(false);
        setState({ loading: false });
      } else {
        notification.error({ message: data.errorMessage });
        setMainShow(false);
        setSuccessShow(false);
        setErrorShow(true);
        setState({ loading: false });
      }
    });
  };

  const handleReceivingCountry = (data) => {
    console.log(data);
  };

  const handleReceiverName = (data) => {
    let receiver = JSON.parse(data);
    setState({
      nickName: receiver.nickName,
    });
  };

  const handleSenderName = (data) => {
    let sender = JSON.parse(data);
    setState({
      sendAccId: sender.sendAccId,
    });
  };

  const handleAmount = (e) => {
    setState({ sendingAmount: e.target.value });
  };

  const handleMessage = (e) => {
    setState({ message: e.target.value });
  };

  const handleAddNew = () => {
    setMainShow(true);
    setSuccessShow(false);
    setErrorShow(false);
    form.setFieldsValue({
      country: "",
      receiver: "",
      sender: "",
      amount: "",
      startDate: "",
      message: "",
    });
  };

  return (
    <div className="main">
      <Form form={form} onFinish={onSubmitScheduleTransactionReminder}>
        <Spinner spinning={state.loading}>
          <div className="sendmoney__page  py-3">
            {mainShow && (
              <>
                <div className="row">
                  <div className="col-lg-6 col-md-6">
                    <label className="form-label">Receiving Country</label>
                    <Form.Item
                      className="form-item"
                      name="country"
                      rules={[
                        {
                          required: true,
                          message: "Please select country.",
                        },
                      ]}
                    >
                      <Select
                        className="w-100"
                        placeholder="Select Country"
                        onChange={handleReceivingCountry}
                      >
                        {state.receiverCountryLists.map((clist, i) => {
                          return (
                            <Option key={i} value={clist.countryName}>
                              {clist.countryName}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                    <label className="form-label">Receiver</label>
                    <Form.Item
                      className="form-item"
                      name="receiver"
                      rules={[
                        {
                          required: true,
                          message: "Please select receiver.",
                        },
                      ]}
                    >
                      <Select
                        className="w-100"
                        placeholder="Select Receiver"
                        onChange={handleReceiverName}
                      >
                        {state.receiverLists.map((clist, i) => {
                          return (
                            <Option key={i} value={JSON.stringify(clist)}>
                              {clist.firstName} {clist.lastName} (
                              {clist.accountNo})
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                    <label className="form-label">Sender</label>
                    <Form.Item
                      className="form-item"
                      name="sender"
                      rules={[
                        {
                          required: true,
                          message: "Please select sender.",
                        },
                      ]}
                    >
                      <Select
                        className="w-100"
                        placeholder="Select Sender"
                        onChange={handleSenderName}
                      >
                        {state.bankAccountLists.map((clist, i) => {
                          return (
                            <Option key={i} value={JSON.stringify(clist)}>
                              {clist.accountHolderName} {clist.accountNo}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                    <label className="form-label">Amount</label>
                    <Form.Item
                      name="amount"
                      rules={[
                        {
                          required: true,
                          message: "Please input your amount.",
                        },
                      ]}
                    >
                      <Input
                        className="bg-secondary-light"
                        type="number"
                        onChange={handleAmount}
                      />
                    </Form.Item>
                    <label className="form-label  mb-1">Start Date</label>
                    <div>
                      <Form.Item
                        className="form-item"
                        name="startDate"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Start Date.",
                          },
                        ]}
                      >
                        <DatePicker
                          placeholder="00 / 00 / 0000"
                          className="w-100 ant-picker-primary-ouline"
                          disabledDate={(current) => {
                            let customDate = moment().format("YYYY-MM-DD");
                            return (
                              current &&
                              current < moment(customDate, "YYYY-MM-DD")
                            );
                          }}
                          onChange={(value, dateString) => {
                            value !== null
                              ? setState({
                                  startDate: dateString,
                                })
                              : setState({ startDate: "" });
                          }}
                        />
                      </Form.Item>
                    </div>
                  </div>
                  <div className="col-lg-1 col-md-1 text-center d-none d-md-block">
                    <span className="_v_line_secondary mt-5"></span>
                  </div>
                  <div className="col-lg-5 col-md-5">
                    <div className="Container">
                      <label className="form-label">Message</label>
                      <Form.Item
                        name="message"
                        rules={[
                          {
                            required: true,
                            message: "Please input your message.",
                          },
                        ]}
                      >
                        <TextArea
                          className="bg-secondary-light"
                          autoComplete="none"
                          placeholder="Enter the message to be displayed in the remiender"
                          onChange={handleMessage}
                        />
                      </Form.Item>
                    </div>
                  </div>
                  <div className="col-12 text-end">
                    <button
                      className="btn btn-light text-primary px-3"
                      htmlType="submit"
                    >
                      Set Reminder
                    </button>
                  </div>
                </div>
              </>
            )}

            {successShow && (
              <>
                <div className="row">
                  <h4>
                    Thank you, your scheduled reminder request has been added.
                  </h4>
                  <button
                    className="btn btn-light text-primary px-3"
                    onClick={handleAddNew}
                  >
                    Add New
                  </button>
                </div>
              </>
            )}

            {errorShow && (
              <>
                <div className="row">
                  <h4>
                    Sorry, your scheduled reminder request has not been added.
                  </h4>
                  <button
                    className="btn btn-light text-primary px-3"
                    onClick={handleAddNew}
                  >
                    Add New
                  </button>
                </div>
              </>
            )}
          </div>
        </Spinner>
      </Form>
    </div>
  );
}
