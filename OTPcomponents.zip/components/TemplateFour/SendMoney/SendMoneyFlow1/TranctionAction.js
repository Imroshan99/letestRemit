import React, { useState, useReducer, useEffect, Fragment } from "react";
import { Row, Col, Modal, Divider, Spin, notification } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { TransactionAPI } from "../../../../apis/TransactionAPI";

import SendMoneyStep from "./Stepper/SendMoneyStep";

export default function TranctionAction(props) {
  const AuthReducer = useSelector((state) => state.user);
  const [loading, setLoader] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isStep: 1,
      innerTitle: "Send Money",
      transactionLists: [],
      favouriteTransactionLists: [],
      promoCode: "",
      sendAmount: 0,
      repeatSendAmount: 0,
      recvAmount: 0,
      totalFee: 0,
      amountPayable: 0,
      displayExRate: 0,
      netRecvAmount: 0,
      isDenefit: false,
      applyPromoCode: false,
      isSelectedBankTransfer: false,
      receiverLists: [],
      receiverName: "",
      receiverAccount: "",
      bankAccountLists: [],
      sourceOFFundLists: [],
      purposeLists: [],
      subPurposeLists: [],
      purposeID: "",
      purposeName: "",
      subPurposeID: "",
      subPurposeName: "",
      sendAccId: "",
      achAccId: "",
      accountNo: "",
      senderName: "",
      sourceFundId: "",
      sourceOfFund: "",
      exRateToken: "",
      txnId: "",
      txnRefno: "",
      rpId: "",
      rptRefNo: "",
      globalpayData: [],
      globalPayId: "",
      order_id: "",
      initiateDate: "",
      expectedDeliveryDate: "",
      txnReceiptDetails: {},
      nickName: "NEWRECV",
      categoryPromoLists: [],
      promoValueWithDesc: "",
      exRateWithPromo: 0,
      promoValue: 0,
      promoValue: 0,
      _isScheduleTransaction: false,
      scheduleTransactionDate: "",
      rgtn: "",
      paymentOptions: [],
    }
  );


  return (
    <Fragment>
      <SendMoneyStep />

      <Modal
        title="Breakup Detail"
        visible={isModalVisible}
        onOk={() => setIsModalVisible(false)}
        onCancel={() => setIsModalVisible(false)}
        footer={false}
      >
        <Row>
          <Col span={12}>
            <p>You Send (A)</p>
          </Col>
          <Col span={12} className="text-end">
            <p className="fw-500">
              {state.sendAmount} {AuthReducer.sendCurrencyCode}
            </p>
          </Col>
          <Col span={12}>
            <p>Tranfer Free (B)</p>
          </Col>
          <Col span={12} className="text-end">
            <p className="fw-500">
              {state.totalFee} {AuthReducer.sendCurrencyCode}
            </p>
          </Col>
          <Divider />

          <Col span={15}>
            <h5 className="fw-500">Total Amount Payable (A+B)</h5>
          </Col>
          <Col span={9} className="text-end">
            <h5 className="fw-500 text-primary">
              {state.amountPayable} {AuthReducer.sendCurrencyCode}
            </h5>
          </Col>
        </Row>
        <Divider />
        <Row className="Privailing-text">
          <Col span={15}>
            <h6 className=" text-primary fw-500">
              Prevailing Exchange rate (C)
            </h6>
          </Col>
          <Col span={9} className="text-end">
            <h6 className="fw-500 text-primary">
              {state.displayExRate} {AuthReducer.recvCurrencyCode}
            </h6>
          </Col>
        </Row>
        <Row className="Privailing-text mt-3">
          <Col span={15}>
            <h6 className=" text-primary fw-500">Expected Delivery Date</h6>
          </Col>
          <Col span={9} className="text-end">
            <h6 className="fw-500 text-primary">
              {state.expectedDeliveryDate}
            </h6>
          </Col>
        </Row>
        {state.promoValueWithDesc != "" && (
          <>
            <Row className="Privailing-text">
              <Col span={15}>
                <h6 className=" text-primary fw-500">Preferential Rate</h6>
              </Col>
              <Col span={9} className="text-end">
                <h6 className="fw-500 text-primary">
                  {state.promoValue} {AuthReducer.recvCurrencyCode}
                </h6>
              </Col>
            </Row>
            <Row className="Privailing-text">
              <Col span={15}>
                <h6 className=" text-primary fw-500">Applied Exchange Rate</h6>
              </Col>
              <Col span={9} className="text-end">
                <h6 className="fw-500 text-primary">
                  {state.exRateWithPromo} {AuthReducer.recvCurrencyCode}
                </h6>
              </Col>
            </Row>

            <Row>
              <Col span={12}>
                <p>You Recieve in {AuthReducer.recvCurrencyCode} (A*C)</p>
              </Col>
              <Col span={12} className="text-end">
                <p className="fw-500">
                  {state.netRecvAmount} {AuthReducer.recvCurrencyCode}
                </p>
              </Col>

              <Col span={15}>
                <p className="fw-500">M2I Brnefit (D)</p>
              </Col>
              <Col span={9} className="text-end">
                <p className="fw-500">
                  {state.benefit} {AuthReducer.recvCurrencyCode}
                </p>
              </Col>
            </Row>
          </>
        )}
        <Divider />
        <Row className="Privailing-text">
          <Col span={15}>
            <h5 className="fw-500">
              Reciever Gets{" "}
              {state.promoValueWithDesc == "" ? "(A*C)" : "(A*C)+D"}
            </h5>
          </Col>
          <Col span={9} className="text-end">
            <h5 className="fw-500 text-primary">
              {state.recvAmount} {AuthReducer.recvCurrencyCode}
            </h5>
          </Col>
        </Row>
      </Modal>
    </Fragment>
  );
}
