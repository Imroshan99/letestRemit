import React, { useEffect, useReducer, Fragment } from "react";
import { useSelector } from "react-redux";
// import DefaultLayout from "../../layout/DefaultLayout";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { config } from "../../../config";
import useHttp from "../../../hooks/useHttp";
import { AuthAPI } from "../../../apis/AuthAPI";
import { ProfileAPI } from "../../../apis/ProfileAPI";

function JumioPageC2R(props) {
  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    isShowFrame: false,
    jumioRedirectURL: "",
  });

  const hookNetverifyInitiate = useHttp(AuthAPI.netverifyInitiate);
  const hookNetverifyResponse = useHttp(AuthAPI.netverifyResponse);
  const hookUpdateKycStatus = useHttp(ProfileAPI.updateKycStatus);
  const hookGetSenderKycDetails = useHttp(ProfileAPI.getSenderKycDetails);

  useEffect(() => {
    onClickJumioVerify();
  }, []);
  useEffect(() => {
    if (state.isShowFrame) {
      window.addEventListener("message", receiveMessage, false);
    }
  }, [state.isShowFrame]);

  function receiveMessage(event) {
    console.log("Event ", event);
    var data = window.JSON.parse(event.data);
    // console.log("ID Verification Web was loaded in an iframe.");
    // console.log("auth-token:", data.authorizationToken);
    // console.log("event-type:", data.eventType);
    // console.log("date-time:", data.dateTime);
    // console.log("workflow-execution-id:", data.workflowExecutionId);
    // console.log("account-id:", data.accountId);
    // console.log("customer-internal-reference:", data.customerInternalReference);
    // console.log("value:", data.payload.value);
    // console.log("metainfo:", data.payload.metainfo);

    if (data.payload.value == "success") {
      (async () => {
        const netVerifyResponseObj = {
          transactionStatus: data.payload.value,
          customerInternalReference: data.customerInternalReference,
          transactionReference: data.transactionReference,
        };
        await netverifyResponse(netVerifyResponseObj);
      })();
    }
  }

  const onClickJumioVerify = () => {
    let payload = {
      requestType: "NETVERIFYINITIATE",
      errorUrl: config.JUMIO_RETURN_URL,
      successUrl: config.JUMIO_RETURN_URL,
      userId: state.userID,
    };

    hookNetverifyInitiate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          isShowFrame: true,
          jumioRedirectURL: data.redirectUrl,
        });
      }
    });
  };

  const netverifyResponse = async (netData) => {
    let payload = {
      requestType: "NETVERIFYAUTH",
      ipAddress: "103.173.120.139",
      netverifyResponse: window.btoa(JSON.stringify(netData)),
      userId: state.userID,
    };

    hookNetverifyResponse.sendRequest(payload, function (data) {
      if (data.status == "S") {
        updateKycStatus();
      }
    });
  };
  const updateKycStatus = () => {
    let payload = {
      requestType: "JUMIOKYC",
      userId: AuthReducer.userID,
    };
    hookUpdateKycStatus.sendRequest(payload, function (data) {
      if (data.status == "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          showCancelButton: false,
          denyButtonText: `Cancel`,
          confirmButtonColor: "#2dbe60",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            props.setIsJumioKYCVisible(false);
            props.setState({ btnDisabled: false });
          }
        });
        // netverifyCallbackResponse(decodeData);
      } else {
      }
    });
  };
  // const getSenderKycDetails = () => {
  //   const payload = {
  //     requestType: "SENDERKYCDTLS",
  //     userId: AuthReducer.userID,
  //   };
  //   hookGetSenderKycDetails.sendRequest(payload, function (data) {
  //     if (data.isIfrKycDone == "Y" && data.isJumioDone == "Y" && data.isViaKycDone == "Y") {
  //       navigate("/new-transaction");
  //     }
  //   });
  // };
  // const netverifyCallbackResponse = (netResData) => {
  //   let data = {
  //     requestId: config.requestId,
  //     requestType: "NETVERIFYCALLBACKRESP",
  //     channelId: config.channelId,
  //     clientId: state.clientId,
  //     groupId: state.groupId,
  //     sessionId: state.sessionId,
  //     ipAddress: "127.0.0.1",
  //     netverifyResponse: window.btoa(JSON.stringify(netResData)),
  //     userId: state.userID
  //   }

  //   if (config.IS_ENC) {
  //     var key = config.key;
  //     var iv = config.iv;
  //     var body = encrypt(data, key, iv);
  //     var pubValue = iv.concat(key);
  //     var identifier = publickey(props.appState.publicKey, pubValue);

  //     var postData = {
  //       body: body,
  //       identifier: identifier,
  //     };
  //   } else {
  //     var postData = data;
  //   }

  //   AuthAPI.netverifyCallbackResponse(postData, props.appState.accessToken)
  //     .then((res) => {
  //       if (config.IS_ENC) {
  //         var decode = decrypt(res.data.body, key, iv);
  //         var decodeData = JSON.parse(decode);
  //       } else {
  //         var decodeData = res.data;
  //       }
  //       if (decodeData.status == "S") {
  //         userRiskProfile();
  //       }
  //       console.log("netverifyCallbackResponse", decodeData);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };

  // const userRiskProfile = () => {

  //   const userRiskProfileData = {
  //     requestId: config.requestId,
  //     requestType: "RISKPROFILE",
  //     channelId: config.channelId,
  //     clientId: state.clientId,
  //     groupId: state.groupId,
  //     sessionId: state.sessionId,
  //     ipAddress: "127.0.0.1",
  //     userId: state.userID
  //   }

  //   if (config.IS_ENC) {
  //     var key = config.key;
  //     var iv = config.iv;
  //     var body = encrypt(userRiskProfileData, key, iv);
  //     var pubValue = iv.concat(key);
  //     var identifier = publickey(props.appState.publicKey, pubValue);

  //     var postData = {
  //       body: body,
  //       identifier: identifier
  //     }
  //   } else {
  //     var postData = userRiskProfileData;
  //   }

  //   ProfileAPI.userRiskProfile(postData, props.appState.accessToken)
  //     .then(res => {
  //       if (config.IS_ENC) {
  //         var decode = decrypt(res.data.body, key, iv);
  //         var decodeData = JSON.parse(decode);
  //       } else {
  //         var decodeData = res.data;
  //       }

  //       if (decodeData.status == "S") {
  //         console.log('userRiskProfile', decodeData)
  //       }
  //     }).catch(error => {
  //       console.log(error)
  //     })
  // }

  return (
    <Fragment>
      <div className="mt-4" style={{ backgroundColor: "#f1f5f6" }}>
        {/* <DefaultLayout> */}
        {state.isShowFrame && (
          <iframe
            title="JumioKYC"
            src={state.jumioRedirectURL}
            width="100%"
            height="500px"
            allow="camera;fullscreen;accelerometer;gyroscope;magnetometer"
            allowfullscreen
          ></iframe>
        )}
        {/* </DefaultLayout> */}
      </div>
    </Fragment>
  );
}

export default JumioPageC2R;
