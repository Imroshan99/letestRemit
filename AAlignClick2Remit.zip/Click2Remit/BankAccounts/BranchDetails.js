import React, { useEffect, useState } from "react";
import Main from "../Layouts/Main";
import Chevronright from "../../../assets/images/click2remit/Chevronright.svg";
import icicilogosvg from "../../../assets/images/click2remit/icicilogo.svg";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import useHttp from "../../../hooks/useHttp";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { useSelector } from "react-redux";
import { notification } from "antd";
import Spinner from "../../../reusable/Spinner";
import { Link } from "react-router-dom";

const BranchDetails = (props) => {
  const AuthReducer = useSelector((state) => state.user);

  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const [bankData, setBankData] = useState([]);
  const [boolean, setBoolean] = useState(false);
  const [loader, setLoader] = useState(false);

  useEffect(() => {
    getBankBanchDetails();
  }, []);
  const getBankBanchDetails = () => {
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: AuthReducer.recvCountryCode,
      bankCode: props.state.beneficiaryBankDetails.bankId
        ? props.state.beneficiaryBankDetails.bankId
        : props?.state?.beneficiaryBankCode,
      bankName: props?.state?.beneficiaryBankDetails?.bankName
        ? props?.state?.beneficiaryBankDetails?.bankName
        : props?.state?.beneBankName,
      cityCode: props?.cityCodeForBankBranch,
      stateCode: props?.stateCodeForBankBranch,
      city: "",
      keyword: "",
    };
    setLoader(true);
    hookGebankBranches.sendRequest(payload, function (data) {
      setLoader(false);
      setBoolean(true);
      if (data.status === "S") {
        setBankData(data.responseData);
      } else {
        notification.error({ message: data.errorMessage });

        // props.setState({ activeStepForm: 9 })
      }
    });
  };
  return (
    <Spinner spinning={loader}>
      <div className="h-100">
        <div className="row h-100 justify-content-center">
          <form>
            <div
              className="align-self-center col-lg-7 col-md-7 col-sm-12 "
              style={{ marginRight: "auto" }}
            >
              <div className="CR-default-box CR-max-width-620">
                <ul className="row CR-side-space mb-3">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 ">
                    <h4 className="text-black CR-font-28 mb-1">Branch details</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-left">Select your bank branch.</p>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row mb-3">
                      {bankData.map((bankData, key) => {
                        return (
                          <>
                            <li
                              style={{ cursor: "pointer" }}
                              className="col-md-12 col-sm-12 col-lg-12 my-2"
                              onClick={() => {
                                props.setState({
                                  ifscBankCode: bankData.branchCode,
                                  activeStepForm: 9,
                                  beneficiaryBankDetails: bankData,
                                });
                              }}
                            >
                              <div className="d-flex justify-content-between w-100 single-box">
                                <div className="">
                                  {/* <div className="mb-2">
                                    <img src={icicilogosvg} />
                                  </div> */}
                                  <div className="d-flex justify-content-between flex-column">
                                    <label className="CR-font-14 text-left CR-fw-500">Branch</label>
                                    <p className="CR-font-14 text-left CR-black-text CR-fw-600 mb-2">
                                      {bankData.bankCity}, {bankData.bankState}
                                    </p>
                                  </div>

                                  <div className="d-flex justify-content-between flex-column">
                                    <label className="CR-font-14 text-left CR-fw-500">
                                      Address
                                    </label>
                                    <p className="CR-font-14 text-left CR-black-text CR-fw-600 mb-2">
                                      {bankData.bankAddress}
                                    </p>
                                  </div>

                                  <div className="d-flex justify-content-between flex-column">
                                    <label className="CR-font-14 text-left CR-fw-500">
                                      IFSC code
                                    </label>
                                    <p className="CR-font-14 text-left CR-black-text CR-fw-600 mb-2">
                                      {bankData.branchCode}
                                    </p>
                                  </div>
                                </div>
                                <span className="align-self-end">
                                  <img src={Chevronright} width="24px" height="24px" />
                                </span>
                              </div>
                            </li>{" "}
                          </>
                        );
                      })}
                    </ul>
                  </li>
                  {boolean && bankData?.length == 0 && (
                    <>
                      <h1 style={{ padding: "100px" }}>No Data Found</h1>
                      {/* <div className="bottom_panel d-flex justify-content-center align-items-center">
                        <div className="d-flex justify-content-between align-items-baseline">
                          <button
                            type="button"
                            onClick={() => {
                              props.parentState({ findIfscComponent: true });
                            }}
                            className="btn btn-primary CR-primary-btn mb-3"
                            style={{ width: "100px", margin: "0 !important" }}
                          >
                            Back
                          </button>
                        </div>
                      </div> */}
                    </>
                  )}
                </ul>
                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-baseline">
                    <span
                      className="Back_arrow"
                      onClick={() => {
                        props.parentState({ findIfscComponent: true });
                      }}
                    >
                      <img src={BackArrow} alt="" />
                      Back
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Spinner>
  );
};

export default BranchDetails;
