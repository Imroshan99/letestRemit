import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Spinner from "../../../reusable/Spinner";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import { Form, notification, Select } from "antd";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { config } from "../../../config";
import { Link, useLocation, useNavigate } from "react-router-dom";
import BankViaPlaid from "./BankViaPlaid";

export default function CreateRemitterAccount(props) {
  // const [form] = Form.useForm();
  const { Option } = Select;
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);
  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: "C2R",
    groupId: "C2R",
    twofa: AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
    nationalities: [],
    stateCities: [],
    _showOTPBOX: false,
    showConfirmBankAccountDetails: false,
    isConfirmAddRecipient: false,
    formData: {},
    verificationToken: "",
    isOTPVerfied: false,
    isModalVisible: false,
    otpType: "RA",

    branchCode: "",
    bankBranch: "",
    bankAddress: "",
    bankState: "",
    bankCity: "",
    bankName: "",
    bankId: "",
    bankCountry: "",
    bankLists: [],
  });

  const hookValidateBankCode = useHttp(BankAccountAPI.validateBankCode);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookCheckDuplicateBankAccount = useHttp(BankAccountAPI.checkDuplicateBankAccount);
  const hookAddBankAccount = useHttp(BankAccountAPI.addBankAccount);

  useEffect(() => {
    getBankList();
  }, []);

  const afterClose = () => {
    if (location.pathname !== "new-transaction") {
      props.accountsList();
    }
    setState({ showConfirmBankAccountDetails: false });

    props.setVisible(false);
  };

  const onChangeBankSortCode = async (e) => {
    if (e.target.value.length >= 1) {
      const payload = {
        requestType: "VALIDATEBANKCODE",
        bankCode: e.target.value,
        userId: state.userID,
        countryCode: "GB",
      };
      setLoader((prevState) => prevState + 1);
      hookValidateBankCode.sendRequest(payload, function (data) {
        setLoader((prevState) => prevState - 1);
        if (data.status == "S") {
        } else {
          props.form.setFields([{ name: "bankSortCode", errors: [data.errorMessage] }]);
        }
      });
    }
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.sendCountryCode,
      userId: state.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetBankLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
      }
    });
  };

  const onFinish = async (value) => {
    let checkDuplicateData = {
      requestType: "CHECKDUPLICATE",
      userId: state.userID,
      bankName: value.bankName.value,
      accountNo: value.accountNo,
    };
    setLoader((prevState) => prevState + 1);
    hookCheckDuplicateBankAccount.sendRequest(checkDuplicateData, function (res) {
      setLoader((prevState) => prevState - 1);
      if (res.status === "S") {
        notification.success({ message: "check duplicate" });
        props.setState({
          addRemitterDetails: value,
          activeStepForm: 14,
        });
      } else {
        notification.error({ message: res.errorMessage });
      }
    });
  };

  return (
    <div class="col-md-8 col-sm-12 col-lg-8 mobile-order-2">
      <Spinner spinning={loader === 0 ? false : true}>
        <div class="CR-account-form CR-otp-form">
          {AuthReducer.regCountryCode === "US" ? (
            <>
              <ul class="row">
                <li class="col-md-12 col-sm-12 col-lg-12 ">
                  <h4 class="text-black ">Remitter account details</h4>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <div className="pb-5">
                    <BankViaPlaid  setState={props.setState} state={props.state}/>
                  </div>
                </li>
              </ul>
            </>
          ) : (
            <>
              <Form form={props.form} onFinish={onFinish}>
                <fieldset>
                  <ul class="row">
                    <li class="col-md-12 col-sm-12 col-lg-12 ">
                      <h4 class="text-black ">Remitter Account Details</h4>
                    </li>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <p class="text-left">Enter details of your new remitter account.</p>
                    </li>
                    <legend></legend>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput showLabel={false} name="fullName" label="Full Name" required>
                        <FloatInput type="text" placeholder="Full Name" />
                      </CustomInput>
                    </li>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput showLabel={false} name="nickName" label="Nick Name" required>
                        <FloatInput type="text" placeholder="Nick Name" />
                      </CustomInput>
                    </li>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput
                        showLabel={false}
                        name="accountNo"
                        label="Account Number"
                        required
                      >
                        <FloatInput type="text" placeholder="Account Number" />
                      </CustomInput>
                    </li>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput
                        name="bankName"
                        label="Bank Name"
                        showLabel={false}
                        showSearch
                        labelInValue
                        placeholder="Select Bank"
                        required
                      >
                        <FloatInput type="select" name="bankName" label="Bank Name">
                          {state.bankLists.map((bank, i) => {
                            return (
                              <Option key={i} value={bank.bankName}>
                                <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                  {bank.bankName}
                                </span>
                              </Option>
                            );
                          })}
                        </FloatInput>
                      </CustomInput>
                    </li>
                    <li class="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput
                        showLabel={false}
                        name="accountType"
                        label="Account Type"
                        placeholder="Account Type"
                        // type="select"
                        labelInValue
                      >
                        <FloatInput
                          placeholder="Account Type"
                          name="accountType"
                          label="Account Type"
                          type="select"
                          className="w-100"
                        >
                          <Option key="ac1" value="S">
                            Saving
                          </Option>
                          <Option key="ac2" value="C">
                            Current / Checking
                          </Option>
                        </FloatInput>
                      </CustomInput>
                    </li>
                  </ul>
                  <div class="bottom_panel">
                    <div class="d-flex justify-content-between align-items-baseline">
                      <span className="Back_arrow">
                        {" "}
                        <img src={BackArrow} alt="backArrow" />
                        Back
                      </span>
                      <button
                        htmlType="submit"
                        class="btn btn-primary CR-primary-btn mb-3"
                        style={{ width: "100px", margin: "0!important" }}
                      >
                        Proceed
                      </button>
                    </div>
                  </div>
                </fieldset>
              </Form>
            </>
          )}
        </div>
      </Spinner>
    </div>
  );
}
