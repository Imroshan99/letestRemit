import React, { useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";

const TermsandConditions = (props) => {
  const [bottom, setBottom] = useState(false);
  const [tncRead, setTncRead] = useState(false);
  const handleScroll = (e) => {
    if (!tncRead) {
      const bottom =
        e.target.scrollHeight - Math.trunc(e.target.scrollTop) - 45 < e.target.clientHeight;
      setBottom(bottom);
      if (bottom) {
        setTncRead(true);
      }
    }
  };
  return (
    <div className="container h-100 m-0 p-0">
      <div className="CR-default-box m-0">
        <ul onScroll={handleScroll} className="row CR-side-space m-0 tnc">
          <li className="back-arrow-nav d-xs-block d-done">
            <img src={BackArrow} alt="" />
          </li>

          <li className="col-md-12 col-sm-12 col-lg-12 ">
            <h4 className="text-black CR-font-28 mb-1">Terms & conditions</h4>
          </li>
          <li className="col-md-12 col-sm-12 col-lg-12">
            <p className="text-left">GDPR/FATCA declaration.</p>
          </li>
          <li className="col-md-12 col-sm-12 col-lg-12">
            <p className="font-16">
              1. Pursuant to the online application (such online application together with an email
              sent to Borrower, by the Bank attaching these terms and conditions and key fact
              statement to the Borrower’s email id registered with the Bank in relation to the
              Borrower’s application for working capital funding, is hereinafter collectively
              referred to as "Online Application") made by the Borrower ("you" or "Borrower"), Kotak
              Mahindra Bank Ltd ("Bank"), has agreed to grant Term Loan Facility, (hereinafter
              referred to as "Loan/Term Loan Facility" or "this Loan/ Term Loan Facility"), at its
              sole discretion and subject to internal checks and the compliance of all terms and
              conditions as specified herein and as specified in the Sanction Letter/
              Facility/security documents (, hereby agrees to lend and you agree to borrow the sum
              as specified in Online Application and Key Fact Statement ("Schedule"). The Bank
              agrees to disburse the Term Loan amount subject to necessary deductions including
              towards payment of Stamp-duty, etc., including applicable taxes to your
              Savings/Current Account maintained with the Bank, and subject to you completing all
              requisite formalities and accepting these Terms and Conditions ("Terms"). <br />
              2. The Term Loan facility along with interest shall be repayable in such manner as are
              set out Key Fact Statement, facility documents, etc.; Credit shall be given only on
              the date of realization of the amount by the Bank. This facility will be extended as a
              Term Loan Facility.
              <br />
              3. The Online Application and "Terms and Conditions" agreed, confirmed, and accepted
              by your, for grant of the Term Loan facility is an integral part of these Terms and
              shall be considered to be part of the Credit Information.
              <br />
              4. You irrevocably agree and consent to the Bank at any time and in any manner
              disclosing and/or making available to any agencies, bureaus (including credit bureaus
              specified by the Reserve Bank of India, affiliates or subsidiaries of the Bank,
              associations, and other persons whosoever any information (including personal and
              financial information) and documents of or relating to you, in such cases where the
              Bank considers appropriate including where such disclosure is permitted or required by
              or under law, circular or guideline or where the Bank is of the view that the
              interests of the Bank require such disclosure of for furnishing such information and
              documents for preparation, publication, and distribution of credit reports and credit
              opinion relating to you, to other persons including banks and financial institutions.
              The provisions of this clause shall survive even after the term/termination of these
              Terms and the repayment of all dues by you
            </p>
          </li>
        </ul>

        <div className="bottom_panel">
          <div className="d-flex justify-content-between align-items-baseline">
            <p className="btn-enable-row">Scroll to the bottom to enable</p>
            <button
              disabled={!bottom}
              onClick={() => props.setState({ tncModal: false, tncCheck: true })}
              className="btn btn-primary CR-primary-btn mb-3"
              style={{height:"55px", width: "150px", margin: "0 !important" }}
            >
              AGREE AND ACCEPT
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsandConditions;
