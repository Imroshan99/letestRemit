import React, { useEffect, useReducer } from "react";
import Main from "../Layouts/Main";
import Chevronright from "../../../assets/images/click2remit/Chevronright.svg";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import searchpng from "../../../assets/images/click2remit/search.png";
import bank1png from "../../../assets/images/click2remit/bank-1.png";
import addsvg from "../../../assets/images/click2remit/Add.svg";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import useHttp from "../../../hooks/useHttp";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { notification } from "antd";
import Spinner from "../../../reusable/Spinner";
import { useState } from "react";

const ManageBeneficiaries = () => {
  const AuthReducer = useSelector((state) => state.user);
  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const hookViewRecipientsDetails = useHttp(ReceiverAPI.viewRecipientsDetails);
  const hookGetPurposeLists = useHttp(TransactionAPI.purposeLists);
  const location = useLocation();
  const navigate = useNavigate();

  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    receiverLists: [],
    purposeLists: [],
    purposeListData: {},
  });
  useEffect(() => {
    getReceiverLists();
    if (location?.state?.pathname === "/new-transaction") {
      getPurposeLists();
    }
  }, []);
  const getPurposeLists = () => {
    const payload = {
      requestType: "PurposeList",
      keyword: "",
      nickName: "NEWRECV",
      recvCountryCode: AuthReducer.recvCountryCode,
      userId: AuthReducer.userID,
    };
    setLoader(true);
    hookGetPurposeLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setState({ purposeLists: data.responseData });
      }
    });
  };
  const getReceiverLists = (nickName) => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: AuthReducer.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };
    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        if (nickName) {
          let _purposeList = {};
          let newReceiver = data.responseData.filter((i) => {
            return i.nickName == nickName.toUpperCase();
          });
          state.purposeLists.filter((purposeData) => {
            if (newReceiver[0].purposeCode == purposeData.purposeCode) {
              _purposeList = { ...purposeData };
            }
          });
          let newRecv = JSON.stringify(newReceiver[0]);
          navigate("/new-transaction", {
            state: {
              autoFillData: {
                ...location?.state?.autoFillData,
                recipient: newRecv,
                purpose: JSON.stringify(_purposeList),
              },
              autoFill: location?.state?.autoFill,
            },
          });
        } else {
          setState({ receiverLists: data.responseData });
          if (data.responseData.length == 0) {
          } else {
          }
        }
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const receiverInfo = (nickName, recordToken) => {
    const payload = {
      requestType: "RECEIVERINFO",
      userId: AuthReducer.userID,
      nickName: nickName,
      recordToken: recordToken,
    };
    setLoader(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        navigate("/view-beneficiary", {
          state: {
            receiverData: data,
            receiverLists: state.receiverLists,
            fromPage: "/my-beneficiary",
          },
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const receiverListFilter = (e) => {
    let value = e.target.value;
    let name;
    let filteredRecieverList = state.receiverLists.filter((i) => {
      name = `${i.firstName} ${i.lastName}`;
      return name.toLowerCase().search(value.toLowerCase()) !== -1;
    });
    setState({ receiverLists: filteredRecieverList });
    if (!value) {
      getReceiverLists();
    }
  };
  return (
    <Main>
      <div className="container h-100">
        <div className="row h-100 justify-content-center">
          <form>
            <div
              className="align-self-center col-lg-7 col-md-7 col-sm-12"
              style={{ marginRight: "auto" }}
            >
              <div className="CR-default-box CR-max-width-620">
                <div className="CR-side-space">
                  <Spinner spinning={loader}>
                    <ul className="row ">
                      <li className="back-arrow-nav d-xs-block d-done">
                        <img src={BackArrow} alt="" />
                      </li>

                      <li className="col-md-12 col-sm-12 col-lg-12 mb-2">
                        <h4 className="text-black CR-font-28 mb-1">Manage beneficiaries</h4>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12  mt-3">
                        <div className="input-group search-input">
                          <span className="position-absolute search-input-icon">
                            <img src={searchpng} width="24px" height="24px" />
                          </span>

                          <input
                            onChange={receiverListFilter}
                            className="CR-border-bottom form-control rounded-pill"
                            type="input"
                            placeholder="Search"
                          />
                        </div>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12 text-start my-4">
                        <button
                          onClick={() => {
                            if (location?.state?.pathname == "/new-transaction") {
                              navigate("/add-beneficiary", {
                                state: {
                                  benificary: 7,
                                  autoFillData: location?.state?.autoFillData,
                                  autoFill: location?.state?.autoFill,
                                  pathname: "/new-transaction",
                                },
                              });
                            } else {
                              navigate("/add-beneficiary", {
                                state: { benificary: 7 },
                              });
                            }
                          }}
                          className="CR-blue-link CR-font-14 CR-fw-500 btn btn-link p-0"
                        >
                          <img
                            src={addsvg}
                            width="16px"
                            height="16px"
                            className="me-2"
                            alt="ADD NEW BENEFICIARY"
                          />
                          ADD NEW BENEFICIARY
                        </button>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12">
                        <p className="text-left mb-0 CR-font-14 CR-fw-500">Beneficiaries</p>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12 ">
                        <ul className="row">
                          {state.receiverLists.map((receiver, key) => {
                            return (
                              <>
                                <li
                                  className="col-md-12 col-sm-12 col-lg-12"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => {
                                    if (location?.state?.pathname == "/new-transaction") {
                                      getReceiverLists(receiver.nickName);
                                    } else {
                                      receiverInfo(receiver.nickName, receiver.recordToken);
                                    }
                                  }}
                                >
                                  <div className="align-items-start d-flex justify-content-start w-100 CR-border-bottom-1 rounded-0 single-box shadow-none  ">
                                    {/* <div className="CR-bank-logo me-3">
                                      <img
                                        src={bank1png}
                                        width="100%"
                                        height="100%"
                                        alt="Bank Logo"
                                      />
                                    </div> */}
                                    <div className="d-flex justify-content-between flex-column w-100">
                                      <label className="CR-font-14 CR-black-text CR-fw-600 text-left ">
                                        {" "}
                                        {`${receiver.firstName} ${receiver.lastName}`}
                                      </label>
                                      <p className="CR-font-12 text-left CR-fw-500 ">
                                        {receiver.bankName}
                                        <span>&#8226;</span> {receiver.unMaskedAccountNo}
                                      </p>
                                    </div>
                                    <img
                                      src={Chevronright}
                                      width="24px"
                                      height="24px"
                                      alt="Right Arrow"
                                    />
                                  </div>
                                </li>
                              </>
                            );
                          })}
                        </ul>
                      </li>
                      {location?.state?.pathname == "/new-transaction" ? (
                        <div className="bottom_panel">
                          <div className="d-flex justify-content-between align-items-baseline">
                            <span
                              onClick={() => {
                                if (location?.state?.pathname === "/new-transaction") {
                                  if (location?.state?.autoFill) {
                                    navigate("/new-transaction", {
                                      state: {
                                        autoFillData: {
                                          ...location?.state?.autoFillData,
                                          purpose: location?.state?.autoFillData?.purpose,
                                        },
                                        autoFill: location?.state?.autoFill,
                                      },
                                    });
                                  } else {
                                    navigate("/new-transaction");
                                  }
                                }
                              }}
                              className="Back_arrow"
                            >
                              {" "}
                              <img src={BackArrow} alt="" />
                              Back
                            </span>
                            {/* <button
                              type="button"
                              onClick={() => setState({ profileComponent: false })}
                              className="btn btn-primary CR-primary-btn mb-3"
                              style={{ width: "100px", margin: "0 !important" }}
                            >
                              Edit
                            </button> */}
                          </div>
                        </div>
                      ) : (
                        <div className="bottom_panel">
                          <div className="d-flex justify-content-between align-items-baseline">
                            <span
                              className="Back_arrow"
                              onClick={() => navigate("/new-transaction")}
                            >
                              <img src={BackArrow} alt="" />
                              Back
                            </span>
                          </div>
                        </div>
                      )}
                    </ul>
                  </Spinner>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
};

export default ManageBeneficiaries;
