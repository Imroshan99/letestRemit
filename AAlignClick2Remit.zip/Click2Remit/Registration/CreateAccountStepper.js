import { useEffect } from "react";
import { Steps } from "antd";
const CreateAccountStepper = (props) => {
  let { state, setState } = props;
  useEffect(() => {
    if (state.activeStepForm === 7) {
      setState({ stepperState: 2 });
    } else if (state.activeStepForm === 8) {
      setState({ stepperState: 3 });
    } else if (state.activeStepForm === 9) {
      setState({ stepperState: 4 });
    } else if (state.activeStepForm === 13) {
      setState({ stepperState: 5 });
    }
  }, [state.activeStepForm]);
  useEffect(() => {
    if (state.windowWidth <= 660) {
      setState({ mobileView: true });
    }
  }, [state.windowWidth]);

  return (
    <div class="col-md-4 col-sm-12 col-lg-4 mobile-order-1 mt-3 mt-md-0">
      <div class="CR-login-form">
        <ul class="row reg-steps antd-step-container">
          <Steps
            responsive={false}
            direction={state.mobileView ? "horizontal" : "vertical"}
            current={state.activeStepForm <= 6 ? state.activeStepForm - 1 : state.stepperState}
            items={
              state.mobileView
                ? [{}, {}, {}, {}, {}, {}]
                : [
                    {
                      title: "Personal details",
                    },
                    {
                      title: "Residential details",
                    },
                    {
                      title: "Beneficiary details",
                    },
                    {
                      title: "Beneficiary residential details",
                    },
                    {
                      title: "Beneficiary bank details",
                    },
                    {
                      title: "Remitter account details",
                    },
                  ]
            }
          />
        </ul>
      </div>
    </div>
  );
};
export default CreateAccountStepper;
